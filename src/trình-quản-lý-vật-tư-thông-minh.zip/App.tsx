

import React, { useState, useMemo, useEffect, useRef } from 'react';
import {
  Page,
  Item,
  CalculatedInventoryItem,
  SlipType,
  RequisitionStatus,
  InventorySlip,
  InventorySlipItem,
  LogEntry,
  Requisition,
  RequisitionItem,
  RequisitionItemStatus,
  Category,
  Subsystem,
  CostCode,
  RequisitionType,
  User,
  UserRole,
  Permission,
  UserStatus,
  InventoryItem
} from './types';
import {
  HomeIcon,
  BoxIcon,
  ArrowDownCircleIcon,
  ArrowUpCircleIcon,
  FileTextIcon,
  AlertTriangleIcon,
  PlusIcon,
  EditIcon,
  TrashIcon,
  XIcon,
  EyeIcon,
  LockIcon,
  CheckCircleIcon,
  HistoryIcon,
  SettingsIcon,
  UsersIcon,
  UserXIcon,
  UserCheckIcon,
  LogOutIcon,
  DownloadIcon,
  UploadIcon,
  PaperclipIcon,
  MenuIcon
} from './components/Icons';
import {
  INITIAL_ITEMS,
  INITIAL_INVENTORY_SLIPS,
  INITIAL_REQUISITIONS,
  INITIAL_SUBSYSTEMS,
  INITIAL_COST_CODES,
  INITIAL_CATEGORIES,
  INITIAL_REQUISITION_TYPES,
  INITIAL_USERS,
  AVAILABLE_PERMISSIONS
} from './constants';
import { suggestRestock } from './services/geminiService';

declare var XLSX: any;

// --- Helper Functions ---
const getWeekOfYear = (date: Date): string => {
  const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  const dayNum = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  const weekNo = Math.ceil((((d.getTime() - yearStart.getTime()) / 86400000) + 1) / 7);
  return `${d.getUTCFullYear()}-W${String(weekNo).padStart(2, '0')}`;
};

const exportRequisitionToExcel = (req: Requisition, itemMap: Map<string, Item>, currentUser: User) => {
  const data: (string | number | null)[][] = [
    ["ĐỘI ĐIỆN NƯỚC CÔNG TRÌNH - PHÒNG KĨ THUẬT", null, null, null, null, null],
    ["BIÊN BẢN TỜ TRÌNH MUA SẮM VẬT TƯ", null, null, null, null, null],
    [],
    [`Mã TT: ${req.code}`, null, null, null, `Ngày: ${req.date}`],
    [`Người tạo: ${req.createdBy}`],
    [`Mục đích: ${req.purpose}`],
    [],
    ["STT", "Tên vật tư", "Đơn vị", "Mã chi phí", "SL Yêu cầu", "Ghi chú"],
  ];
  
  req.items.forEach((item, index) => {
    const itemName = itemMap.get(item.itemId)?.name || 'Không rõ';
    const itemUnit = itemMap.get(item.itemId)?.unit || '';
    data.push([
      index + 1,
      itemName,
      itemUnit,
      item.costCode,
      item.requestedQuantity,
      item.notes,
    ]);
  });

  data.push(
    [],
    [null, null, null, null, `Ngày ..... tháng ..... năm .....`],
    [],
    ["Người lập biểu", null, "Phụ trách bộ phận", null, "Giám đốc"],
    [], [], [],
    [currentUser.fullName]
  );
  
  const ws = XLSX.utils.aoa_to_sheet(data);

  ws['!merges'] = [
    { s: { r: 0, c: 0 }, e: { r: 0, c: 5 } }, // Company Name
    { s: { r: 1, c: 0 }, e: { r: 1, c: 5 } }, // Title
    { s: { r: data.length - 5, c: 0 }, e: { r: data.length - 5, c: 1 } }, // Nguoi lap
    { s: { r: data.length - 5, c: 2 }, e: { r: data.length - 5, c: 3 } }, // phu trach
    { s: { r: data.length - 5, c: 4 }, e: { r: data.length - 5, c: 5 } }, // giam doc
    { s: { r: data.length - 1, c: 0 }, e: { r: data.length - 1, c: 1 } }, // creator name
  ];

  ws['!cols'] = [
    { wch: 5 },   // STT
    { wch: 40 },  // Tên vật tư
    { wch: 10 },  // Đơn vị
    { wch: 20 },  // Mã chi phí
    { wch: 15 },  // SL Yêu cầu
    { wch: 40 },  // Ghi chú
  ];

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Tờ trình");
  XLSX.writeFile(wb, `To_Trinh_${req.code}.xlsx`);
};

const exportInventoryReportToExcel = (inventory: CalculatedInventoryItem[]) => {
  const today = new Date().toLocaleDateString('vi-VN');
  const data: (string | number | null)[][] = [
    ["BÁO CÁO TỒN KHO VẬT TƯ"],
    [`Ngày: ${today}`],
    [],
    ["STT", "Mã VT", "Tên vật tư", "Đơn vị", "Tồn đầu kỳ", "Tổng nhập", "Tổng xuất", "Tồn cuối kỳ"],
  ];

  inventory.forEach((invItem, index) => {
    data.push([
      index + 1,
      invItem.item.code,
      invItem.item.name,
      invItem.item.unit,
      invItem.item.initialStock,
      invItem.totalReceipts,
      invItem.totalIssues,
      invItem.stock,
    ]);
  });

  const ws = XLSX.utils.aoa_to_sheet(data);
  ws['!merges'] = [{ s: { r: 0, c: 0 }, e: { r: 0, c: 7 } }];
  ws['!cols'] = [
    { wch: 5 },  // STT
    { wch: 15 }, // Mã VT
    { wch: 40 }, // Tên vật tư
    { wch: 10 }, // Đơn vị
    { wch: 12 }, // Tồn đầu
    { wch: 12 }, // Tổng nhập
    { wch: 12 }, // Tổng xuất
    { wch: 12 }, // Tồn cuối
  ];
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "BaoCaoTonKho");
  XLSX.writeFile(wb, `Bao_cao_ton_kho_${today.replace(/\//g, '-')}.xlsx`);
};

const exportInventoryCountSheetToExcel = (inventory: CalculatedInventoryItem[]) => {
  const today = new Date().toLocaleDateString('vi-VN');
  const data: (string | number | null)[][] = [
    ["PHIẾU KIỂM KÊ KHO VẬT TƯ"],
    [`Ngày kiểm kê: ${today}`],
    [],
    ["STT", "Mã VT", "Tên vật tư", "Đơn vị", "Tồn kho Sổ sách", "Tồn kho Thực tế", "Chênh lệch", "Ghi chú"],
  ];

  inventory.forEach((invItem, index) => {
    data.push([
      index + 1,
      invItem.item.code,
      invItem.item.name,
      invItem.item.unit,
      invItem.stock,
      null,
      null,
      null,
    ]);
  });

  data.push(
    [],
    [],
    ["Người kiểm kê", null, "Thủ kho", null, "Kế toán trưởng"],
  );

  const ws = XLSX.utils.aoa_to_sheet(data);
  ws['!merges'] = [
      { s: { r: 0, c: 0 }, e: { r: 0, c: 7 } },
      { s: { r: data.length - 1, c: 0 }, e: { r: data.length - 1, c: 1 } },
      { s: { r: data.length - 1, c: 2 }, e: { r: data.length - 1, c: 3 } },
      { s: { r: data.length - 1, c: 4 }, e: { r: data.length - 1, c: 5 } },
  ];
  ws['!cols'] = [
    { wch: 5 },   // STT
    { wch: 15 },  // Mã VT
    { wch: 40 },  // Tên vật tư
    { wch: 10 },  // Đơn vị
    { wch: 15 },  // Tồn kho Sổ sách
    { wch: 15 },  // Tồn kho Thực tế
    { wch: 15 },  // Chênh lệch
    { wch: 30 },  // Ghi chú
  ];
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "PhieuKiemKe");
  XLSX.writeFile(wb, `Phieu_kiem_ke_${today.replace(/\//g, '-')}.xlsx`);
};


// --- Page Components ---

const Dashboard: React.FC<{ 
  lowStockItems: CalculatedInventoryItem[];
  highStockItems: CalculatedInventoryItem[];
  currentUser: User;
}> = ({ lowStockItems, highStockItems, currentUser }) => {
  const [suggestion, setSuggestion] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  
  const canManageItems = currentUser.permissions.includes('manage_items');

  const handleSuggestRestock = async () => {
    if (lowStockItems.length === 0) return;
    setIsLoading(true);
    setError('');
    setSuggestion('');
    try {
      const itemsToRestock: InventoryItem[] = lowStockItems.map(i => ({
          item: i.item,
          stock: i.stock,
      }));
      const result = await suggestRestock(itemsToRestock);
      setSuggestion(result);
    } catch (err) {
      console.error(err);
      setError('Lỗi khi tạo đề xuất. Vui lòng thử lại.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Dashboard</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-xl font-semibold mb-4 flex items-center">
            <AlertTriangleIcon className="mr-2 text-red-500" />
            Vật tư sắp hết hàng ({lowStockItems.length})
          </h2>
          {lowStockItems.length > 0 ? (
            <>
              <ul className="space-y-2 max-h-60 overflow-y-auto">
                {lowStockItems.map(({ item, stock }) => (
                  <li key={item.id} className="flex justify-between items-center p-2 rounded hover:bg-gray-50">
                    <div>
                      {item.name} ({item.unit})
                      <p className="text-xs text-gray-400">Ngưỡng: {item.warningThresholdLower}</p>
                    </div>
                    <span className="font-bold text-red-500">{stock}</span>
                  </li>
                ))}
              </ul>
              {canManageItems && (
                <button
                  onClick={handleSuggestRestock}
                  disabled={isLoading}
                  className="mt-4 w-full bg-blue-600 text-white py-2 px-4 rounded-lg font-semibold hover:bg-blue-700 disabled:bg-blue-300 flex items-center justify-center transition-colors"
                >
                  {isLoading ? 'Đang tạo đề xuất...' : 'Tạo đề xuất nhập hàng với AI'}
                </button>
              )}
            </>
          ) : (
            <p className="text-gray-500">Không có vật tư nào sắp hết hàng.</p>
          )}
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-xl font-semibold mb-4 flex items-center">
            <AlertTriangleIcon className="mr-2 text-orange-500" />
            Vật tư tồn kho cao ({highStockItems.length})
          </h2>
          {highStockItems.length > 0 ? (
            <ul className="space-y-2 max-h-60 overflow-y-auto">
              {highStockItems.map(({ item, stock }) => (
                <li key={item.id} className="flex justify-between items-center p-2 rounded hover:bg-gray-50">
                  <div>
                    {item.name} ({item.unit})
                    <p className="text-xs text-gray-400">Ngưỡng: {item.warningThresholdUpper}</p>
                  </div>
                  <span className="font-bold text-orange-500">{stock}</span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-gray-500">Không có vật tư nào tồn kho cao.</p>
          )}
        </div>

        <div className="bg-white p-6 rounded-lg shadow md:col-span-2 lg:col-span-1">
          <h2 className="text-xl font-semibold mb-4">Đề xuất từ AI</h2>
          {isLoading && <p className="text-gray-500">AI đang suy nghĩ...</p>}
          {error && <p className="text-red-500">{error}</p>}
          {suggestion && (
            <div className="prose max-w-none whitespace-pre-wrap bg-gray-50 p-4 rounded-md">{suggestion}</div>
          )}
          {!isLoading && !suggestion && !error && (
            <p className="text-gray-500">Nhấn nút bên cạnh để tạo đề xuất nhập hàng tự động.</p>
          )}
        </div>
      </div>
    </div>
  );
};

const ItemsPage: React.FC<{
  items: Item[];
  setItems: React.Dispatch<React.SetStateAction<Item[]>>;
  inventory: CalculatedInventoryItem[];
  allSlips: InventorySlip[];
  categories: Category[];
  addLog: (action: string, details: string) => void;
  currentUser: User;
}> = ({ items, setItems, inventory, allSlips, categories, addLog, currentUser }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<Item | null>(null);
  const [deletingItemId, setDeletingItemId] = useState<string | null>(null);
  const [viewingItem, setViewingItem] = useState<CalculatedInventoryItem | null>(null);
  const [isExportMenuOpen, setIsExportMenuOpen] = useState(false);
  const exportMenuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
        if (exportMenuRef.current && !exportMenuRef.current.contains(event.target as Node)) {
            setIsExportMenuOpen(false);
        }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
        document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [exportMenuRef]);
  
  const canManage = currentUser.permissions.includes('manage_items');
  
  const inventoryMap = useMemo(() => new Map(inventory.map(i => [i.item.id, i])), [inventory]);

  const handleOpenModal = (item: Item | null = null) => {
    if (!canManage) return;
    if (item) {
      setEditingItem({ ...item });
    } else {
      const newItemCode = `VT-${String(items.length + 1).padStart(3, '0')}`;
      setEditingItem({
        id: `item-${Date.now()}`,
        code: newItemCode,
        name: '',
        unit: '',
        category: '',
        initialStock: 0,
        unitPrice: 0,
        warningThresholdLower: 10,
        warningThresholdUpper: 100,
      });
    }
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingItem(null);
  };

  const handleSaveItem = () => {
    if (!editingItem) return;

    const isEditing = items.some(i => i.id === editingItem.id);
    if (isEditing) {
      setItems(items.map(i => i.id === editingItem.id ? editingItem : i));
      addLog('Cập nhật Vật tư', `Mã VT: ${editingItem.code}`);
    } else {
      setItems([...items, editingItem]);
      addLog('Tạo Vật tư', `Mã VT: ${editingItem.code}`);
    }
    handleCloseModal();
  };

  const handleDeleteItem = (id: string) => {
    const itemToDelete = items.find(i => i.id === id);
    if (itemToDelete) {
      addLog('Xóa Vật tư', `Mã VT: ${itemToDelete.code}`);
      setItems(items.filter(i => i.id !== id));
    }
    setDeletingItemId(null);
  };

  const formInputStyle = "mt-1 p-2 border rounded w-full bg-white text-dark-text focus:ring-1 focus:ring-primary focus:border-primary transition-shadow";
  const formSelectStyle = "mt-1 p-2 border rounded w-full bg-white text-dark-text focus:ring-1 focus:ring-primary focus:border-primary transition-shadow";

  return (
    <div>
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 mb-6">
        <h1 className="text-3xl font-bold">Quản lý Vật tư</h1>
        <div className="flex flex-wrap items-center gap-2 self-start sm:self-auto">
            <div className="relative" ref={exportMenuRef}>
                <button
                    onClick={() => setIsExportMenuOpen(!isExportMenuOpen)}
                    className="bg-secondary text-white py-2 px-4 rounded-lg font-semibold hover:bg-green-600 flex items-center transition-colors"
                >
                    <DownloadIcon className="mr-2" />
                    Xuất báo cáo
                </button>
                {isExportMenuOpen && (
                    <div className="absolute right-0 mt-2 w-56 bg-white rounded-md shadow-lg z-20 border">
                        <ul className="py-1">
                            <li>
                                <a href="#" onClick={(e) => { e.preventDefault(); exportInventoryReportToExcel(inventory); addLog('Xuất Báo cáo', 'Báo cáo Tồn kho'); setIsExportMenuOpen(false); }} className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                                    Báo cáo Tồn kho
                                </a>
                            </li>
                            <li>
                                <a href="#" onClick={(e) => { e.preventDefault(); exportInventoryCountSheetToExcel(inventory); addLog('Xuất Báo cáo', 'Phiếu Kiểm kê Vật tư'); setIsExportMenuOpen(false); }} className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                                    Phiếu Kiểm kê
                                </a>
                            </li>
                        </ul>
                    </div>
                )}
            </div>

            {canManage && (
                <button onClick={() => handleOpenModal()} className="bg-primary text-white py-2 px-4 rounded-lg font-semibold hover:bg-primary-dark flex items-center transition-colors">
                    <PlusIcon className="mr-2" />
                    Thêm Vật tư
                </button>
            )}
        </div>
      </div>
      <div className="bg-white p-4 rounded-lg shadow overflow-x-auto">
        <table className="w-full min-w-max">
          <thead>
            <tr className="text-left text-sm font-semibold text-gray-600 border-b bg-gray-50">
              <th className="p-3">Mã VT</th>
              <th className="p-3">Tên vật tư</th>
              <th className="p-3">Đơn vị</th>
              <th className="p-3 text-right">Tồn đầu</th>
              <th className="p-3 text-right">Tổng nhập</th>
              <th className="p-3 text-right">Tổng xuất</th>
              <th className="p-3 text-right">Tồn cuối</th>
              {canManage && <th className="p-3 text-center">Hành động</th>}
            </tr>
          </thead>
          <tbody>
            {inventory.map(invItem => {
              const { item, stock, totalReceipts, totalIssues } = invItem;
              const stockStatusColor = stock < item.warningThresholdLower
                ? 'text-red-500'
                : stock > item.warningThresholdUpper && item.warningThresholdUpper > 0
                ? 'text-orange-500'
                : 'text-gray-800';
              
              return (
                <tr key={item.id} className="border-b hover:bg-gray-50 text-sm">
                  <td className="p-3">{item.code}</td>
                  <td className="p-3 font-medium">{item.name}</td>
                  <td className="p-3">{item.unit}</td>
                  <td className="p-3 text-right">{item.initialStock}</td>
                  <td className="p-3 text-right text-green-600">{totalReceipts}</td>
                  <td className="p-3 text-right text-red-600">{totalIssues}</td>
                  <td className={`p-3 font-bold text-right ${stockStatusColor}`}>{stock}</td>
                  {canManage && (
                    <td className="p-3 flex justify-center items-center space-x-2">
                      <button onClick={() => setViewingItem(invItem)} className="text-gray-500 hover:text-blue-600" title="Xem chi tiết"><EyeIcon /></button>
                      <button onClick={() => handleOpenModal(item)} className="text-gray-500 hover:text-green-600" title="Sửa"><EditIcon /></button>
                      <button onClick={() => setDeletingItemId(item.id)} className="text-gray-500 hover:text-red-600" title="Xóa"><TrashIcon /></button>
                    </td>
                  )}
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
      
      {isModalOpen && editingItem && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
          <div className="bg-white rounded-lg shadow-xl p-6 w-[95%] sm:w-full max-w-lg">
            <h2 className="text-xl font-bold mb-4">{items.some(i => i.id === editingItem.id) ? 'Sửa Vật tư' : 'Thêm Vật tư'}</h2>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div><label className="block text-sm font-medium text-gray-700">Mã vật tư</label><input type="text" value={editingItem.code} onChange={e => setEditingItem({ ...editingItem, code: e.target.value })} className={formInputStyle} /></div>
                <div><label className="block text-sm font-medium text-gray-700">Đơn vị tính</label><input type="text" value={editingItem.unit} onChange={e => setEditingItem({ ...editingItem, unit: e.target.value })} className={formInputStyle} /></div>
              </div>
              <div><label className="block text-sm font-medium text-gray-700">Tên vật tư</label><input type="text" value={editingItem.name} onChange={e => setEditingItem({ ...editingItem, name: e.target.value })} className={formInputStyle} /></div>
              <div><label className="block text-sm font-medium text-gray-700">Loại vật tư</label><select value={editingItem.category} onChange={e => setEditingItem({ ...editingItem, category: e.target.value })} className={formSelectStyle}><option value="">Chọn loại</option>{categories.map(c => <option key={c} value={c}>{c}</option>)}</select></div>
              <div className="grid grid-cols-2 gap-4">
                <div><label className="block text-sm font-medium text-gray-700">Tồn đầu kỳ</label><input type="number" value={editingItem.initialStock} onChange={e => setEditingItem({ ...editingItem, initialStock: Number(e.target.value) })} className={formInputStyle} /></div>
                <div><label className="block text-sm font-medium text-gray-700">Đơn giá</label><input type="number" value={editingItem.unitPrice} onChange={e => setEditingItem({ ...editingItem, unitPrice: Number(e.target.value) })} className={formInputStyle} /></div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div><label className="block text-sm font-medium text-gray-700">Cảnh báo tồn dưới</label><input type="number" value={editingItem.warningThresholdLower} onChange={e => setEditingItem({ ...editingItem, warningThresholdLower: Number(e.target.value) })} className={formInputStyle} /></div>
                <div><label className="block text-sm font-medium text-gray-700">Cảnh báo tồn trên</label><input type="number" value={editingItem.warningThresholdUpper} onChange={e => setEditingItem({ ...editingItem, warningThresholdUpper: Number(e.target.value) })} className={formInputStyle} /></div>
              </div>
            </div>
            <div className="flex justify-end space-x-4 mt-6">
              <button onClick={handleCloseModal} className="bg-gray-200 text-gray-800 py-2 px-4 rounded-lg font-semibold hover:bg-gray-300">Hủy</button>
              <button onClick={handleSaveItem} className="bg-primary text-white py-2 px-4 rounded-lg font-semibold hover:bg-primary-dark">Lưu</button>
            </div>
          </div>
        </div>
      )}
      
      {viewingItem && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
          <div className="bg-white rounded-lg shadow-2xl p-6 sm:p-8 w-[95%] sm:w-full max-w-4xl max-h-[90vh] flex flex-col">
            <div className="flex justify-between items-center border-b pb-4 mb-6">
              <h2 className="text-2xl font-bold text-gray-800">Chi tiết Vật tư: {viewingItem.item.name}</h2>
              <button onClick={() => setViewingItem(null)} className="text-gray-500 hover:text-gray-800"><XIcon className="h-6 w-6" /></button>
            </div>
            <div className="overflow-y-auto flex-grow pr-2">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6 p-4 bg-gray-50 rounded-lg">
                <div className="text-center p-4 bg-white rounded-lg shadow-sm">
                  <p className="text-sm text-gray-500">Tồn đầu kỳ</p>
                  <p className="text-2xl font-bold">{viewingItem.item.initialStock}</p>
                </div>
                <div className="text-center p-4 bg-white rounded-lg shadow-sm">
                  <p className="text-sm text-gray-500">Tổng Nhập</p>
                  <p className="text-2xl font-bold text-green-600">+{viewingItem.totalReceipts}</p>
                </div>
                <div className="text-center p-4 bg-white rounded-lg shadow-sm">
                  <p className="text-sm text-gray-500">Tổng Xuất</p>
                  <p className="text-2xl font-bold text-red-600">-{viewingItem.totalIssues}</p>
                </div>
                <div className="text-center p-4 bg-blue-100 text-blue-800 rounded-lg shadow-sm md:col-span-3">
                  <p className="text-sm font-semibold">TỒN KHO CUỐI KỲ</p>
                  <p className="text-4xl font-extrabold">{viewingItem.stock}</p>
                </div>
              </div>
              
               <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6 text-sm">
                  <div><span className="font-semibold text-gray-500 block">Mã VT:</span> {viewingItem.item.code}</div>
                  <div><span className="font-semibold text-gray-500 block">Đơn vị:</span> {viewingItem.item.unit}</div>
                  <div><span className="font-semibold text-gray-500 block">Loại:</span> {viewingItem.item.category}</div>
                  <div><span className="font-semibold text-gray-500 block">Đơn giá:</span> {viewingItem.item.unitPrice.toLocaleString()}</div>
                  <div><span className="font-semibold text-gray-500 block">Cảnh báo dưới:</span> {viewingItem.item.warningThresholdLower}</div>
                  <div><span className="font-semibold text-gray-500 block">Cảnh báo trên:</span> {viewingItem.item.warningThresholdUpper}</div>
              </div>

              <h3 className="text-lg font-bold text-gray-700 border-t pt-4 mb-4">Lịch sử Giao dịch</h3>
              <div className="overflow-x-auto max-h-64">
                <table className="w-full min-w-max text-sm">
                  <thead className="sticky top-0 bg-gray-100">
                    <tr className="text-left font-semibold text-gray-600">
                      <th className="p-2">Ngày</th>
                      <th className="p-2">Mã Phiếu</th>
                      <th className="p-2">Loại</th>
                      <th className="p-2 text-right">Số lượng</th>
                      <th className="p-2">Lý do</th>
                    </tr>
                  </thead>
                  <tbody>
                    {allSlips
                      .flatMap(slip => 
                        slip.items
                          .filter(si => si.itemId === viewingItem.item.id)
                          .map(si => ({
                            date: slip.date,
                            code: slip.code,
                            type: slip.type === SlipType.Receipt ? 'Nhập' : 'Xuất',
                            quantity: si.quantity,
                            reason: slip.reason,
                            status: slip.status,
                          }))
                      )
                      .filter(tx => tx.status !== 'Đang mở' || tx.type === 'Xuất')
                      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                      .map((tx, index) => (
                        <tr key={index} className="border-b hover:bg-gray-50">
                          <td className="p-2">{tx.date}</td>
                          <td className="p-2">{tx.code}</td>
                          <td className={`p-2 font-semibold ${tx.type === 'Nhập' ? 'text-green-600' : 'text-red-600'}`}>{tx.type}</td>
                          <td className="p-2 text-right font-medium">{tx.type === 'Nhập' ? '+' : '-'}{tx.quantity}</td>
                          <td className="p-2">{tx.reason}</td>
                        </tr>
                      ))
                    }
                  </tbody>
                </table>
              </div>
            </div>
            <div className="mt-6 pt-4 border-t flex justify-end">
              <button onClick={() => setViewingItem(null)} className="bg-gray-200 text-gray-800 py-2 px-6 rounded-lg font-semibold hover:bg-gray-300">Đóng</button>
            </div>
          </div>
        </div>
      )}

      {deletingItemId && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
          <div className="bg-white rounded-lg shadow-xl p-6 w-[95%] sm:w-full max-w-sm">
            <h2 className="text-xl font-bold mb-4">Xác nhận xóa</h2>
            <p className="text-gray-600 mb-6">Bạn có chắc chắn muốn xóa vật tư này? Hành động này không thể hoàn tác.</p>
            <div className="flex justify-end space-x-4">
              <button onClick={() => setDeletingItemId(null)} className="bg-gray-200 text-gray-800 py-2 px-4 rounded-lg font-semibold hover:bg-gray-300">Hủy</button>
              <button onClick={() => handleDeleteItem(deletingItemId)} className="bg-red-600 text-white py-2 px-4 rounded-lg font-semibold hover:bg-red-700">Xóa</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const ReceiptsPage: React.FC<{
  allSlips: InventorySlip[];
  setAllSlips: React.Dispatch<React.SetStateAction<InventorySlip[]>>;
  requisitions: Requisition[];
  setRequisitions: React.Dispatch<React.SetStateAction<Requisition[]>>;
  items: Item[];
  itemMap: Map<string, Item>;
  addLog: (action: string, details: string) => void;
  currentUser: User;
}> = ({ allSlips, setAllSlips, requisitions, setRequisitions, items, itemMap, addLog, currentUser }) => {
  const receipts = allSlips.filter(s => s.type === SlipType.Receipt);
  
  const [isSlipModalOpen, setIsSlipModalOpen] = useState(false);
  const [editingSlip, setEditingSlip] = useState<InventorySlip | null>(null);
  const [isItemModalOpen, setIsItemModalOpen] = useState(false);
  const [editingSlipItem, setEditingSlipItem] = useState<InventorySlipItem | null>(null);
  const [deletingSlipId, setDeletingSlipId] = useState<string | null>(null);
  const [viewingSlip, setViewingSlip] = useState<InventorySlip | null>(null);
  const [isReqSelectOpen, setIsReqSelectOpen] = useState(false);
  const reqSelectRef = useRef<HTMLDivElement>(null);

  const canManage = currentUser.permissions.includes('manage_receipts');

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (reqSelectRef.current && !reqSelectRef.current.contains(event.target as Node)) {
        setIsReqSelectOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [reqSelectRef]);

  const availableRequisitions = useMemo(() => 
    requisitions.filter(r => r.status === RequisitionStatus.Approved && r.items.some(i => i.itemStatus === RequisitionItemStatus.Pending)), 
  [requisitions]);
  
  const requisitionMap = useMemo(() => new Map(requisitions.map(r => [r.id, r])), [requisitions]);

  const handleOpenSlipModal = (slip: InventorySlip | null = null) => {
    if (!canManage) return;
    if (slip) {
      setEditingSlip({ ...slip, items: [...slip.items] });
    } else {
      const newSlipCode = `PNK-${String(receipts.length + 1).padStart(3, '0')}`;
      setEditingSlip({
        id: `slip-${Date.now()}`,
        code: newSlipCode,
        type: SlipType.Receipt,
        date: new Date().toISOString().split('T')[0],
        createdBy: currentUser.fullName,
        reason: '',
        items: [],
        status: 'Đang mở',
        receiptType: 'Nhận ngoài',
        requisitionIds: []
      });
    }
    setIsSlipModalOpen(true);
  };
  
  const handleCloseSlipModal = () => {
      setIsSlipModalOpen(false);
      setEditingSlip(null);
  };

  const handleSaveSlip = () => {
    if (!editingSlip) return;
    const isEditing = allSlips.some(s => s.id === editingSlip.id);
    if (isEditing) {
      setAllSlips(allSlips.map(s => s.id === editingSlip.id ? editingSlip : s));
      addLog('Cập nhật Phiếu Nhập', `Mã phiếu: ${editingSlip.code}`);
    } else {
      setAllSlips([...allSlips, editingSlip]);
      addLog('Tạo Phiếu Nhập', `Mã phiếu: ${editingSlip.code}`);
    }
    handleCloseSlipModal();
  };

  const handleDeleteSlip = (id: string) => {
    const slipToDelete = allSlips.find(s => s.id === id);
    if (slipToDelete) {
        addLog('Xóa Phiếu Nhập', `Mã phiếu: ${slipToDelete.code}`);
        setAllSlips(allSlips.filter(s => s.id !== id));
    }
    setDeletingSlipId(null);
  };

  const handleOpenItemModal = (item: InventorySlipItem | null) => {
    setEditingSlipItem(item ? { ...item } : { itemId: '', quantity: 1, requisitionItemId: `temp-${Date.now()}` });
    setIsItemModalOpen(true);
  };

  const handleCloseItemModal = () => {
    setIsItemModalOpen(false);
    setEditingSlipItem(null);
  };

  const handleSaveItem = () => {
    if (editingSlip && editingSlipItem) {
      const newItems = [...editingSlip.items];
      const key = editingSlipItem.requisitionItemId || editingSlipItem.itemId;
      const existingItemIndex = newItems.findIndex(i => (i.requisitionItemId || i.itemId) === key);

      if (existingItemIndex > -1) {
        newItems[existingItemIndex] = editingSlipItem;
      } else {
         newItems.push(editingSlipItem);
      }
      setEditingSlip({ ...editingSlip, items: newItems });
      handleCloseItemModal();
    }
  };

  const handleDeleteItem = (itemToDelete: InventorySlipItem) => {
    if (editingSlip) {
      const key = itemToDelete.requisitionItemId || itemToDelete.itemId;
      setEditingSlip({
        ...editingSlip,
        items: editingSlip.items.filter(item => (item.requisitionItemId || item.itemId) !== key)
      });
    }
  };

  const handleCloseSlip = (id: string) => {
    const slipToClose = allSlips.find(s => s.id === id);
    if (!slipToClose) return;

    if (slipToClose.receiptType === 'Theo tờ trình') {
        setRequisitions(prevRequisitions => {
            const newRequisitions = JSON.parse(JSON.stringify(prevRequisitions));
            slipToClose.items.forEach(receiptItem => {
                if (receiptItem.requisitionItemId) {
                    // Find the requisition containing this item
                    for (const req of newRequisitions) {
                        const targetReqItem = req.items.find((ri: RequisitionItem) => ri.id === receiptItem.requisitionItemId);
                        if (targetReqItem) {
                            targetReqItem.receivedQuantity += receiptItem.quantity;
                            if (targetReqItem.receivedQuantity >= targetReqItem.requestedQuantity) {
                                targetReqItem.itemStatus = RequisitionItemStatus.Completed;
                            }
                            break; // Found the item, move to the next receipt item
                        }
                    }
                }
            });
            return newRequisitions;
        });
    }

    setAllSlips(allSlips.map(s => s.id === id ? { ...s, status: 'Đã đóng' } : s));
    addLog('Đóng Phiếu Nhập', `Mã phiếu: ${slipToClose.code}`);
  };
  
  const selectedRequisitionItems = useMemo(() => {
    if (!editingSlip || !editingSlip.requisitionIds || editingSlip.requisitionIds.length === 0) return [];
    
    return editingSlip.requisitionIds.flatMap(reqId => {
      const req = requisitions.find(r => r.id === reqId);
      return req ? req.items.filter(i => i.itemStatus === RequisitionItemStatus.Pending) : [];
    });
  }, [editingSlip, requisitions]);
  
  const handleRequisitionSelectionChange = (reqId: string) => {
    if (!editingSlip) return;
    const currentIds = editingSlip.requisitionIds || [];
    const newIds = currentIds.includes(reqId)
      ? currentIds.filter(id => id !== reqId)
      : [...currentIds, reqId];
    
    const reason = newIds.length > 0 
      ? `Theo tờ trình ${newIds.map(id => requisitionMap.get(id)?.code).join(', ')}`
      : '';
    
    setEditingSlip({ ...editingSlip, requisitionIds: newIds, reason, items: [] });
  };


  const formInputStyle = "mt-1 p-2 border rounded w-full bg-white text-dark-text focus:ring-1 focus:ring-primary focus:border-primary transition-shadow";
  const formSelectStyle = "mt-1 p-2 border rounded w-full bg-white text-dark-text focus:ring-1 focus:ring-primary focus:border-primary transition-shadow";

  return (
    <div>
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 mb-6">
        <h1 className="text-3xl font-bold">Quản lý Phiếu Nhập</h1>
        {canManage && (
          <button onClick={() => handleOpenSlipModal()} className="bg-primary text-white py-2 px-4 rounded-lg font-semibold hover:bg-primary-dark flex items-center transition-colors">
            <PlusIcon className="mr-2" />
            Thêm Phiếu Nhập
          </button>
        )}
      </div>
      <div className="bg-white p-4 rounded-lg shadow overflow-x-auto">
        <table className="w-full min-w-max">
          <thead>
            <tr className="text-left text-sm font-semibold text-gray-600 border-b bg-gray-50">
              <th className="p-3">Mã Phiếu</th>
              <th className="p-3">Ngày</th>
              <th className="p-3">Người tạo</th>
              <th className="p-3">Lý do</th>
              <th className="p-3">Loại</th>
              <th className="p-3">Đính kèm</th>
              <th className="p-3">Trạng thái</th>
              <th className="p-3 text-center">Hành động</th>
            </tr>
          </thead>
          <tbody>
            {receipts.map(slip => (
              <tr key={slip.id} className="border-b hover:bg-gray-50 text-sm">
                <td className="p-3 font-medium">{slip.code}</td>
                <td className="p-3">{slip.date}</td>
                <td className="p-3">{slip.createdBy}</td>
                <td className="p-3">{slip.reason}</td>
                <td className="p-3">{slip.receiptType}</td>
                <td className="p-3 text-center">
                  {slip.handoverRecordUrl && <PaperclipIcon className="text-gray-500 inline-block" title={slip.handoverRecordUrl} />}
                </td>
                <td className="p-3">
                    <span className={`px-2 py-1 text-xs font-semibold rounded-full ${slip.status === 'Đã đóng' ? 'bg-yellow-100 text-yellow-800' : 'bg-blue-100 text-blue-800'}`}>
                        {slip.status}
                    </span>
                </td>
                 <td className="p-3 flex justify-center items-center space-x-2">
                  <button onClick={() => setViewingSlip(slip)} className="text-gray-500 hover:text-blue-600" title="Xem"><EyeIcon /></button>
                  {slip.status !== 'Đã đóng' && canManage ? (
                    <>
                      <button onClick={() => handleOpenSlipModal(slip)} className="text-gray-500 hover:text-green-600" title="Sửa"><EditIcon /></button>
                      <button onClick={() => setDeletingSlipId(slip.id)} className="text-gray-500 hover:text-red-600" title="Xóa"><TrashIcon /></button>
                      <button onClick={() => handleCloseSlip(slip.id)} className="text-gray-500 hover:text-yellow-600" title="Đóng phiếu"><LockIcon /></button>
                    </>
                  ) : slip.status === 'Đã đóng' ? <span className="text-yellow-600 flex items-center text-xs font-semibold px-2"><LockIcon className="h-4 w-4 mr-1"/> Đã khóa</span> : null}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

       {viewingSlip && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
            <div className="bg-white rounded-lg shadow-2xl p-6 sm:p-8 w-[95%] sm:w-full max-w-2xl max-h-[90vh] flex flex-col">
                 <div className="flex justify-between items-center border-b pb-4 mb-6">
                    <h2 className="text-2xl font-bold text-gray-800">Chi tiết Phiếu Nhập: {viewingSlip.code}</h2>
                    <button onClick={() => setViewingSlip(null)} className="text-gray-500 hover:text-gray-800"><XIcon className="h-6 w-6" /></button>
                </div>
                 <div className="grid grid-cols-2 gap-4 mb-6 text-sm">
                    <div><span className="font-semibold text-gray-500">Mã phiếu:</span> {viewingSlip.code}</div>
                    <div><span className="font-semibold text-gray-500">Ngày:</span> {viewingSlip.date}</div>
                    <div><span className="font-semibold text-gray-500">Người tạo:</span> {viewingSlip.createdBy}</div>
                    <div><span className="font-semibold text-gray-500">Loại:</span> {viewingSlip.receiptType}</div>
                    <div className="col-span-2"><span className="font-semibold text-gray-500">Lý do:</span> {viewingSlip.reason}</div>
                    {viewingSlip.handoverRecordUrl && (
                        <div className="col-span-2">
                            <span className="font-semibold text-gray-500">Biên bản bàn giao:</span>
                            <span className="ml-2 text-blue-600 font-medium cursor-pointer hover:underline flex items-center">
                                <PaperclipIcon className="mr-1 h-4 w-4" />
                                {viewingSlip.handoverRecordUrl}
                            </span>
                        </div>
                    )}
                </div>
                <h3 className="text-lg font-bold text-gray-700 border-t pt-4 mb-4">Chi tiết vật tư</h3>
                <div className="overflow-y-auto flex-grow">
                     <table className="w-full text-sm">
                        <thead>
                            <tr className="text-left font-semibold text-gray-600 bg-gray-50">
                                <th className="p-2">Vật tư</th>
                                <th className="p-2 text-right">Số lượng</th>
                            </tr>
                        </thead>
                        <tbody>
                            {viewingSlip.items.map((item, index) => (
                                <tr key={index} className="border-b">
                                    <td className="p-2 font-medium">{itemMap.get(item.itemId)?.name}</td>
                                    <td className="p-2 text-right">{item.quantity}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
                 <div className="mt-6 pt-4 border-t flex justify-end">
                    <button onClick={() => setViewingSlip(null)} className="bg-gray-200 text-gray-800 py-2 px-6 rounded-lg font-semibold hover:bg-gray-300">Đóng</button>
                </div>
            </div>
        </div>
       )}

        {isSlipModalOpen && editingSlip && (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
                <div className="bg-white rounded-lg shadow-xl p-6 w-[95%] sm:w-full max-w-2xl max-h-[90vh] flex flex-col">
                    <h2 className="text-xl font-bold mb-4">{allSlips.some(s => s.id === editingSlip.id) ? 'Sửa Phiếu Nhập' : 'Thêm Phiếu Nhập'}</h2>
                    <div className="grid grid-cols-2 gap-4 mb-4">
                        <input type="text" value={editingSlip.code} onChange={e => setEditingSlip({ ...editingSlip, code: e.target.value })} placeholder="Mã phiếu" className={formInputStyle}/>
                        <input type="date" value={editingSlip.date} onChange={e => setEditingSlip({ ...editingSlip, date: e.target.value })} className={formInputStyle}/>
                        <input type="text" value={editingSlip.createdBy} onChange={e => setEditingSlip({ ...editingSlip, createdBy: e.target.value })} placeholder="Người tạo" className={formInputStyle}/>
                        <select value={editingSlip.receiptType} onChange={e => setEditingSlip({...editingSlip, receiptType: e.target.value as any, requisitionIds: [], items: []})} className={formSelectStyle}>
                            <option value="Nhận ngoài">Nhận ngoài</option>
                            <option value="Theo tờ trình">Theo tờ trình</option>
                        </select>
                        {editingSlip.receiptType === 'Theo tờ trình' ? (
                           <div className="relative col-span-2" ref={reqSelectRef}>
                                <div onClick={() => setIsReqSelectOpen(!isReqSelectOpen)} className={`${formInputStyle} cursor-pointer flex flex-wrap gap-1 items-center`}>
                                {(editingSlip.requisitionIds || []).length > 0 ? (
                                    (editingSlip.requisitionIds || []).map(id => (
                                    <span key={id} className="bg-blue-100 text-blue-800 text-xs font-semibold px-2 py-1 rounded-full flex items-center">
                                        {requisitionMap.get(id)?.code}
                                        <button onClick={(e) => { e.stopPropagation(); handleRequisitionSelectionChange(id); }} className="ml-2 text-blue-500 hover:text-blue-700">
                                            <XIcon className="h-3 w-3" />
                                        </button>
                                    </span>
                                    ))
                                ) : (
                                    <span className="text-gray-500">Chọn tờ trình</span>
                                )}
                                </div>
                                {isReqSelectOpen && (
                                <div className="absolute z-10 mt-1 w-full bg-white border border-gray-300 rounded-md shadow-lg max-h-60 overflow-y-auto">
                                    {availableRequisitions.map(req => (
                                    <label key={req.id} className="flex items-center p-2 hover:bg-gray-100 cursor-pointer">
                                        <input
                                        type="checkbox"
                                        checked={(editingSlip.requisitionIds || []).includes(req.id)}
                                        onChange={() => handleRequisitionSelectionChange(req.id)}
                                        className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                                        />
                                        <span className="ml-3 text-sm">{req.code} - {req.purpose}</span>
                                    </label>
                                    ))}
                                </div>
                                )}
                            </div>
                        ) : (
                           <input type="text" value={editingSlip.reason} onChange={e => setEditingSlip({ ...editingSlip, reason: e.target.value })} placeholder="Lý do nhập" className={`${formInputStyle} col-span-2`}/>
                        )}
                         <div className="col-span-2">
                            <label className="block text-sm font-medium text-gray-700">Biên bản bàn giao</label>
                            <div className="mt-1 flex items-center space-x-2">
                                <label className="w-full cursor-pointer bg-white border border-gray-300 rounded-md shadow-sm px-3 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 flex items-center">
                                    <UploadIcon className="w-5 h-5 mr-2 text-gray-500"/>
                                    <span>{editingSlip.handoverRecordUrl || 'Chọn tệp...'}</span>
                                    <input 
                                        type="file" 
                                        className="hidden"
                                        onChange={(e) => {
                                            if (e.target.files && e.target.files[0] && editingSlip) {
                                                setEditingSlip({...editingSlip, handoverRecordUrl: e.target.files[0].name });
                                                addLog('Tải lên tệp', `Phiếu nhập: ${editingSlip.code}, Tệp: ${e.target.files[0].name}`);
                                            }
                                        }}
                                    />
                                </label>
                                {editingSlip.handoverRecordUrl && (
                                    <button
                                        type="button"
                                        onClick={() => {
                                            if (editingSlip) {
                                                const slipCode = editingSlip.code;
                                                const fileName = editingSlip.handoverRecordUrl;
                                                setEditingSlip(prev => {
                                                    const updatedSlip = { ...prev! };
                                                    delete updatedSlip.handoverRecordUrl;
                                                    return updatedSlip;
                                                });
                                                addLog('Xóa tệp đính kèm', `Phiếu nhập: ${slipCode}, Tệp: ${fileName}`);
                                            }
                                        }}
                                        className="p-2 text-gray-500 hover:text-red-600"
                                        title="Xóa tệp"
                                    >
                                        <TrashIcon className="w-5 h-5"/>
                                    </button>
                                )}
                            </div>
                        </div>
                    </div>
                     <div className="flex justify-between items-center mb-2">
                        <h3 className="font-semibold">Danh sách vật tư</h3>
                        <button onClick={() => handleOpenItemModal(null)} disabled={editingSlip.receiptType === 'Theo tờ trình' && (!editingSlip.requisitionIds || editingSlip.requisitionIds.length === 0)} className="bg-secondary text-white text-sm py-1 px-3 rounded-md hover:bg-green-600 flex items-center disabled:bg-gray-400"><PlusIcon className="mr-1 h-4 w-4" />Thêm vật tư</button>
                    </div>
                     <div className="border rounded-md overflow-y-auto flex-grow mb-4">
                        <table className="w-full text-sm">
                            <thead className="bg-gray-50"><tr><th className="p-2 text-left">Vật tư</th><th className="p-2 text-right">Số lượng</th><th className="p-2 text-center">Hành động</th></tr></thead>
                            <tbody>
                                {editingSlip.items.map((item, index) => (
                                    <tr key={index} className="border-t">
                                        <td className="p-2">{itemMap.get(item.itemId)?.name}</td>
                                        <td className="p-2 text-right">{item.quantity}</td>
                                        <td className="p-2 flex justify-center items-center space-x-2">
                                            <button onClick={() => handleOpenItemModal(item)} className="text-gray-500 hover:text-green-600"><EditIcon className="h-4 w-4"/></button>
                                            <button onClick={() => handleDeleteItem(item)} className="text-gray-500 hover:text-red-600"><TrashIcon className="h-4 w-4"/></button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                    <div className="flex justify-end space-x-4">
                        <button onClick={handleCloseSlipModal} className="bg-gray-200 text-gray-800 py-2 px-4 rounded-lg">Hủy</button>
                        <button onClick={handleSaveSlip} className="bg-primary text-white py-2 px-4 rounded-lg">Lưu</button>
                    </div>
                </div>
            </div>
        )}

        {isItemModalOpen && editingSlip && editingSlipItem && (
             <div className="fixed inset-0 bg-black bg-opacity-60 flex justify-center items-center z-50">
                <div className="bg-white rounded-lg shadow-xl p-6 w-[95%] sm:w-full max-w-md">
                    <h2 className="text-xl font-bold mb-4">Thêm/Sửa Vật tư Nhập</h2>
                    {editingSlip.receiptType === 'Theo tờ trình' ? (() => {
                      const reqItem = selectedRequisitionItems.find(i => i.id === editingSlipItem.requisitionItemId);
                      const maxQuantity = reqItem ? reqItem.requestedQuantity - reqItem.receivedQuantity : undefined;
                      return (
                        <div className="space-y-4">
                          <div>
                            <label className="block text-sm font-medium">Vật tư từ tờ trình</label>
                            <select
                              value={editingSlipItem.requisitionItemId}
                              onChange={e => {
                                const reqItemId = e.target.value;
                                const selectedReqItem = selectedRequisitionItems.find(i => i.id === reqItemId);
                                if (selectedReqItem) {
                                  setEditingSlipItem({ ...editingSlipItem, requisitionItemId: reqItemId, itemId: selectedReqItem.itemId });
                                }
                              }}
                              className={formSelectStyle}
                            >
                              <option value="">Chọn vật tư cần nhập</option>
                              {selectedRequisitionItems.map(reqItem => (
                                <option key={reqItem.id} value={reqItem.id}>
                                  {itemMap.get(reqItem.itemId)?.name} (Tờ trình: {requisitions.find(r => r.items.some(i => i.id === reqItem.id))?.code})
                                </option>
                              ))}
                            </select>
                          </div>
                          <div>
                            <label className="block text-sm font-medium">Số lượng</label>
                            <input
                              type="number"
                              value={editingSlipItem.quantity}
                              onChange={e => setEditingSlipItem({ ...editingSlipItem, quantity: parseInt(e.target.value, 10) || 0 })}
                              className={formInputStyle}
                              max={maxQuantity}
                            />
                            {reqItem && (
                              <p className="text-xs text-gray-500 mt-1">Cần nhập: {maxQuantity} {itemMap.get(reqItem.itemId)?.unit}</p>
                            )}
                          </div>
                        </div>
                      );
                    })() : (
                        <div className="space-y-4">
                            <div>
                                <label className="block text-sm font-medium">Vật tư</label>
                                <select value={editingSlipItem.itemId} onChange={e => setEditingSlipItem({ ...editingSlipItem, itemId: e.target.value })} className={formSelectStyle}>
                                    <option value="">Chọn vật tư</option>
                                    {items.map(item => <option key={item.id} value={item.id}>{item.name}</option>)}
                                </select>
                            </div>
                            <div>
                                <label className="block text-sm font-medium">Số lượng</label>
                                <input type="number" value={editingSlipItem.quantity} onChange={e => setEditingSlipItem({ ...editingSlipItem, quantity: parseInt(e.target.value, 10) || 0 })} className={formInputStyle}/>
                            </div>
                        </div>
                    )}
                     <div className="flex justify-end space-x-4 mt-6">
                        <button onClick={handleCloseItemModal} className="bg-gray-200 text-gray-800 py-2 px-4 rounded-lg">Hủy</button>
                        <button onClick={handleSaveItem} className="bg-primary text-white py-2 px-4 rounded-lg">Lưu</button>
                    </div>
                </div>
             </div>
        )}

        {deletingSlipId && (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
                <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-sm">
                    <h2 className="text-xl font-bold mb-4">Xác nhận xóa</h2>
                    <p className="text-gray-600 mb-6">Bạn có chắc chắn muốn xóa phiếu nhập này? Hành động này không thể hoàn tác.</p>
                    <div className="flex justify-end space-x-4">
                        <button onClick={() => setDeletingSlipId(null)} className="bg-gray-200 text-gray-800 py-2 px-4 rounded-lg">Hủy</button>
                        <button onClick={() => handleDeleteSlip(deletingSlipId)} className="bg-red-600 text-white py-2 px-4 rounded-lg">Xóa</button>
                    </div>
                </div>
            </div>
        )}
    </div>
  );
};

interface IssuesPageProps {
  allSlips: InventorySlip[];
  setAllSlips: React.Dispatch<React.SetStateAction<InventorySlip[]>>;
  items: Item[];
  itemMap: Map<string, Item>;
  subsystems: Subsystem[];
  costCodes: CostCode[];
  addLog: (action: string, details: string) => void;
  currentUser: User;
}

const IssuesPage: React.FC<IssuesPageProps> = ({ allSlips, setAllSlips, items, itemMap, subsystems, costCodes, addLog, currentUser }) => {
  const slips = allSlips.filter(s => s.type === SlipType.Issue);

  const [isSlipModalOpen, setIsSlipModalOpen] = useState(false);
  const [editingSlip, setEditingSlip] = useState<InventorySlip | null>(null);
  const [isItemModalOpen, setIsItemModalOpen] = useState(false);
  const [editingSlipItem, setEditingSlipItem] = useState<InventorySlipItem | null>(null);
  const [itemErrors, setItemErrors] = useState<{ [key: string]: string }>({});
  const [deletingSlipId, setDeletingSlipId] = useState<string | null>(null);
  const [viewingSlip, setViewingSlip] = useState<InventorySlip | null>(null);
  const [weekConflict, setWeekConflict] = useState(false);
  const [completingSlip, setCompletingSlip] = useState<InventorySlip | null>(null);
  const [completionFile, setCompletionFile] = useState<File | null>(null);

  const canManage = currentUser.permissions.includes('manage_issues');

  const purposes = useMemo(() => [...new Set(costCodes.map(c => c.purpose))], [costCodes]);
  const methods = useMemo(() => [...new Set(costCodes.map(c => c.method))], [costCodes]);

  useEffect(() => {
    if (editingSlip?.date) {
      const week = getWeekOfYear(new Date(editingSlip.date));
      const conflict = slips.some(s => s.weekOfYear === week && s.id !== editingSlip.id);
      setWeekConflict(conflict);
    } else {
      setWeekConflict(false);
    }
  }, [editingSlip?.date, slips, editingSlip?.id]);
  
  useEffect(() => {
    if (!editingSlipItem || !editingSlipItem.itemId || !editingSlipItem.subsystem || !editingSlipItem.purpose || !editingSlipItem.method) {
        if (editingSlipItem && editingSlipItem.costCode) {
            setEditingSlipItem(prev => ({ ...prev!, costCode: '' }));
        }
        return;
    }

    const item = itemMap.get(editingSlipItem.itemId);
    if (!item) return;

    const foundCostCode = costCodes.find(cc =>
        cc.classification === item.category &&
        cc.subsystem === editingSlipItem.subsystem &&
        cc.purpose === editingSlipItem.purpose &&
        cc.method === editingSlipItem.method
    );

    const newCostCode = foundCostCode ? foundCostCode.code : '';
    if (newCostCode !== editingSlipItem.costCode) {
        setEditingSlipItem(prev => ({ ...prev!, costCode: newCostCode }));
    }
  }, [editingSlipItem?.itemId, editingSlipItem?.subsystem, editingSlipItem?.purpose, editingSlipItem?.method, itemMap, costCodes, editingSlipItem]);


  const handleOpenSlipModal = (slip: InventorySlip | null = null) => {
    if (!canManage) return;
    if (slip) {
      setEditingSlip({ ...slip, items: [...slip.items] });
    } else {
      const newSlipCode = `PXK-${String(slips.length + 1).padStart(3, '0')}`;
      setEditingSlip({
        id: `slip-${Date.now()}`,
        code: newSlipCode,
        type: SlipType.Issue,
        date: new Date().toISOString().split('T')[0],
        createdBy: currentUser.fullName,
        reason: '',
        items: [],
        status: 'Đang mở',
      });
    }
    setIsSlipModalOpen(true);
  };

  const handleCloseSlipModal = () => {
    setIsSlipModalOpen(false);
    setEditingSlip(null);
    setWeekConflict(false);
  };

  const handleSaveSlip = () => {
    if (!editingSlip || weekConflict) return;

    const slipToSave = {
      ...editingSlip,
      weekOfYear: editingSlip.date ? getWeekOfYear(new Date(editingSlip.date)) : undefined,
    };

    const isEditing = allSlips.some(s => s.id === slipToSave.id);

    if (isEditing) {
      setAllSlips(allSlips.map(s => (s.id === slipToSave.id ? slipToSave : s)));
       addLog('Cập nhật Phiếu Xuất', `Mã phiếu: ${slipToSave.code}`);
    } else {
      setAllSlips([...allSlips, slipToSave]);
       addLog('Tạo Phiếu Xuất', `Mã phiếu: ${slipToSave.code}`);
    }
    handleCloseSlipModal();
  };

  const handleDeleteSlip = (id: string) => {
    const slipToDelete = allSlips.find(s => s.id === id);
    if (slipToDelete) {
        addLog('Xóa Phiếu Xuất', `Mã phiếu: ${slipToDelete.code}`);
        setAllSlips(allSlips.filter(s => s.id !== id));
    }
    setDeletingSlipId(null);
  };

  const handleOpenItemModal = (item: InventorySlipItem | null) => {
    setEditingSlipItem(item ? { ...item } : { itemId: '', quantity: 1, subsystem: '', purpose: '', method: '', costCode: '', handler: '', notes: '', requisitionItemId: `temp-${Date.now()}` });
    setIsItemModalOpen(true);
    setItemErrors({});
  };

  const handleCloseItemModal = () => {
    setIsItemModalOpen(false);
    setEditingSlipItem(null);
  };

  const handleSaveItem = () => {
    const errors: { [key: string]: string } = {};
    if (!editingSlipItem?.itemId) errors.itemId = 'Vui lòng chọn vật tư.';
    if ((editingSlipItem?.quantity || 0) <= 0) errors.quantity = 'Số lượng phải lớn hơn 0.';
    if (Object.keys(errors).length > 0) {
      setItemErrors(errors);
      return;
    }

    if (editingSlip && editingSlipItem) {
      const newItems = [...editingSlip.items];
      const existingItemIndex = newItems.findIndex(i => i.requisitionItemId === editingSlipItem.requisitionItemId);
      
      if (existingItemIndex > -1) {
        newItems[existingItemIndex] = editingSlipItem;
      } else {
         newItems.push(editingSlipItem);
      }

      setEditingSlip({ ...editingSlip, items: newItems });
      handleCloseItemModal();
    }
  };

  const handleDeleteItem = (itemToDelete: InventorySlipItem) => {
    if (editingSlip) {
      setEditingSlip({
        ...editingSlip,
        items: editingSlip.items.filter(item => item.requisitionItemId !== itemToDelete.requisitionItemId)
      });
    }
  };
  
  const handleViewSlip = (slip: InventorySlip) => {
    setViewingSlip(slip);
  };

  const handleOpenCompleteModal = (slip: InventorySlip) => {
    if (!canManage) return;
    setCompletingSlip(slip);
  };

  const handleCloseCompleteModal = () => {
      setCompletingSlip(null);
      setCompletionFile(null);
  };

  const handleCompleteSlip = () => {
      if (!completingSlip || !completionFile) return;

      setAllSlips(allSlips.map(s => s.id === completingSlip.id ? {
          ...s,
          status: 'Đã hoàn thành',
          completionReportUrl: completionFile.name,
      } : s));
      
      addLog('Hoàn thành Phiếu Xuất', `Mã phiếu: ${completingSlip.code}, Biên bản: ${completionFile.name}`);

      handleCloseCompleteModal();
  };

  const formInputStyle = "p-2 border rounded bg-white text-dark-text focus:ring-1 focus:ring-primary focus:border-primary transition-shadow";
  const formSelectStyle = "mt-1 p-2 border rounded w-full bg-white text-dark-text focus:ring-1 focus:ring-primary focus:border-primary transition-shadow";
  const formTextareaStyle = "mt-1 p-2 border rounded w-full bg-white text-dark-text focus:ring-1 focus:ring-primary focus:border-primary transition-shadow";
  const formInputErrorStyle = "border-red-500";


  return (
    <div>
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 mb-6">
        <h1 className="text-3xl font-bold">Quản lý Phiếu Xuất</h1>
        {canManage && (
          <button
            onClick={() => handleOpenSlipModal()}
            className="bg-primary text-white py-2 px-4 rounded-lg font-semibold hover:bg-primary-dark flex items-center transition-colors"
          >
            <PlusIcon className="mr-2" />
            Thêm Phiếu Xuất
          </button>
        )}
      </div>

      <div className="bg-white p-4 rounded-lg shadow overflow-x-auto">
        <table className="w-full min-w-max">
          <thead>
            <tr className="text-left text-sm font-semibold text-gray-600 border-b bg-gray-50">
              <th className="p-3">Mã Phiếu</th>
              <th className="p-3">Ngày</th>
              <th className="p-3">Người tạo</th>
              <th className="p-3">Nơi nhận</th>
              <th className="p-3">Tuần</th>
              <th className="p-3">Trạng thái</th>
              <th className="p-3 text-center">Hành động</th>
            </tr>
          </thead>
          <tbody>
            {slips.map(slip => (
              <tr key={slip.id} className="border-b hover:bg-gray-50 text-sm">
                <td className="p-3 font-medium">{slip.code}</td>
                <td className="p-3">{slip.date}</td>
                <td className="p-3">{slip.createdBy}</td>
                <td className="p-3">{slip.reason}</td>
                <td className="p-3">{slip.weekOfYear}</td>
                <td className="p-3">
                  <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                    slip.status === 'Đã hoàn thành' ? 'bg-green-100 text-green-800' : 
                    slip.status === 'Đã đóng' ? 'bg-yellow-100 text-yellow-800' : 'bg-blue-100 text-blue-800'}`
                  }>
                    {slip.status}
                  </span>
                </td>
                <td className="p-3 flex justify-center items-center space-x-2">
                  <button onClick={() => handleViewSlip(slip)} className="text-gray-500 hover:text-blue-600" title="Xem chi tiết"><EyeIcon /></button>
                  {slip.status !== 'Đã hoàn thành' && canManage ? (
                    <>
                      <button onClick={() => handleOpenSlipModal(slip)} className="text-gray-500 hover:text-green-600" title="Sửa phiếu"><EditIcon /></button>
                      <button onClick={() => setDeletingSlipId(slip.id)} className="text-gray-500 hover:text-red-600" title="Xóa phiếu"><TrashIcon /></button>
                      {slip.status === 'Đã đóng' && (
                        <button onClick={() => handleOpenCompleteModal(slip)} title="Hoàn thành phiếu" className="text-gray-500 hover:text-secondary"><CheckCircleIcon /></button>
                      )}
                    </>
                  ) : slip.status === 'Đã hoàn thành' ? (
                    <span className="text-green-600 flex items-center text-xs font-semibold px-2">
                      <LockIcon className="h-4 w-4 mr-1"/> Đã khóa
                    </span>
                  ) : null}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

       {/* View Slip Modal */}
      {viewingSlip && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
          <div className="bg-white rounded-lg shadow-2xl p-6 sm:p-8 w-[95%] sm:w-full max-w-4xl max-h-[90vh] flex flex-col">
            <div className="flex justify-between items-center border-b pb-4 mb-6">
              <h2 className="text-2xl font-bold text-gray-800">Chi tiết Phiếu Xuất: {viewingSlip.code}</h2>
              <button onClick={() => setViewingSlip(null)} className="text-gray-500 hover:text-gray-800"><XIcon className="h-6 w-6" /></button>
            </div>
            
            <div className="overflow-y-auto flex-grow pr-2">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-4 mb-6 text-sm">
                <div className="flex flex-col"><span className="font-semibold text-gray-500">Mã phiếu:</span> <span className="text-gray-800">{viewingSlip.code}</span></div>
                <div className="flex flex-col"><span className="font-semibold text-gray-500">Ngày xuất:</span> <span className="text-gray-800">{viewingSlip.date}</span></div>
                <div className="flex flex-col"><span className="font-semibold text-gray-500">Người tạo:</span> <span className="text-gray-800">{viewingSlip.createdBy}</span></div>
                <div className="flex flex-col"><span className="font-semibold text-gray-500">Tuần:</span> <span className="text-gray-800">{viewingSlip.weekOfYear}</span></div>
                <div className="flex flex-col md:col-span-2"><span className="font-semibold text-gray-500">Nơi nhận/Lý do:</span> <span className="text-gray-800">{viewingSlip.reason}</span></div>
                <div className="flex flex-col"><span className="font-semibold text-gray-500">Trạng thái:</span> 
                  <span className={`mt-1 w-fit px-2 py-1 text-xs font-semibold rounded-full ${
                      viewingSlip.status === 'Đã hoàn thành' ? 'bg-green-100 text-green-800' : 
                      viewingSlip.status === 'Đã đóng' ? 'bg-yellow-100 text-yellow-800' : 'bg-blue-100 text-blue-800'}`
                    }>
                      {viewingSlip.status}
                    </span>
                </div>
                {viewingSlip.completionReportUrl && (
                  <div className="flex flex-col md:col-span-2">
                    <span className="font-semibold text-gray-500">Biên bản hoàn thành:</span>
                    <span className="text-blue-600 font-medium cursor-pointer hover:underline">{viewingSlip.completionReportUrl}</span>
                  </div>
                )}
              </div>

              <h3 className="text-lg font-bold text-gray-700 border-t pt-4 mb-4">Chi tiết vật tư</h3>
              <div className="overflow-x-auto">
                <table className="w-full min-w-max text-sm">
                  <thead>
                    <tr className="text-left font-semibold text-gray-600 bg-gray-50">
                      <th className="p-3">Vật tư</th>
                      <th className="p-3 text-right">Số lượng</th>
                      <th className="p-3">Phân hệ</th>
                      <th className="p-3">Mục đích</th>
                      <th className="p-3">Mã chi phí</th>
                      <th className="p-3">Người xuất</th>
                      <th className="p-3">Ghi chú</th>
                    </tr>
                  </thead>
                  <tbody>
                    {viewingSlip.items.map((item, index) => (
                      <tr key={index} className="border-b hover:bg-gray-50">
                        <td className="p-3 font-medium">{itemMap.get(item.itemId)?.name}</td>
                        <td className="p-3 text-right">{item.quantity}</td>
                        <td className="p-3">{item.subsystem}</td>
                        <td className="p-3">{item.purpose}</td>
                        <td className="p-3">{item.costCode}</td>
                        <td className="p-3">{item.handler}</td>
                        <td className="p-3">{item.notes || '-'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t flex justify-end">
              <button
                onClick={() => setViewingSlip(null)}
                className="bg-gray-200 text-gray-800 py-2 px-6 rounded-lg font-semibold hover:bg-gray-300 transition-colors"
              >
                Đóng
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Slip Add/Edit Modal */}
      {isSlipModalOpen && editingSlip && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
          <div className="bg-white rounded-lg shadow-xl p-6 w-[95%] sm:w-full max-w-3xl max-h-[90vh] flex flex-col">
            <h2 className="text-xl font-bold mb-4">{allSlips.some(s => s.id === editingSlip.id) ? 'Sửa Phiếu Xuất' : 'Thêm Phiếu Xuất'}</h2>
            <div className="grid grid-cols-2 gap-4 mb-4">
              <input type="text" value={editingSlip.code} onChange={e => setEditingSlip({ ...editingSlip, code: e.target.value })} placeholder="Mã phiếu" className={formInputStyle} />
              <input type="date" value={editingSlip.date} onChange={e => setEditingSlip({ ...editingSlip, date: e.target.value })} className={formInputStyle} />
              <input type="text" value={editingSlip.createdBy} onChange={e => setEditingSlip({ ...editingSlip, createdBy: e.target.value })} placeholder="Người tạo" className={formInputStyle} />
              <input type="text" value={editingSlip.reason} onChange={e => setEditingSlip({ ...editingSlip, reason: e.target.value })} placeholder="Nơi nhận" className={formInputStyle} />
            </div>
            {weekConflict && (
                <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-2 rounded-md mb-4 flex items-center">
                    <AlertTriangleIcon className="mr-2" />
                    <span>Cảnh báo: Đã tồn tại phiếu xuất cho tuần này.</span>
                </div>
            )}
            <div className="flex justify-between items-center mb-2">
                <h3 className="font-semibold">Danh sách vật tư</h3>
                <button onClick={() => handleOpenItemModal(null)} className="bg-secondary text-white text-sm py-1 px-3 rounded-md hover:bg-green-600 flex items-center"><PlusIcon className="mr-1 h-4 w-4" />Thêm vật tư</button>
            </div>
            <div className="border rounded-md overflow-y-auto flex-grow mb-4">
              <table className="w-full min-w-max text-sm">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="p-2 text-left">Vật tư</th>
                    <th className="p-2 text-right">Số lượng</th>
                    <th className="p-2 text-left">Người xuất</th>
                    <th className="p-2 text-left">Ghi chú</th>
                    <th className="p-2 text-center">Hành động</th>
                  </tr>
                </thead>
                <tbody>
                  {editingSlip.items.map((item, index) => (
                    <tr key={index} className="border-t">
                      <td className="p-2 font-medium">{itemMap.get(item.itemId)?.name}</td>
                      <td className="p-2 text-right">{item.quantity}</td>
                      <td className="p-2">{item.handler}</td>
                      <td className="p-2 truncate max-w-xs">{item.notes}</td>
                      <td className="p-2 flex justify-center items-center space-x-2">
                        <button onClick={() => handleOpenItemModal(item)} className="text-gray-500 hover:text-green-600"><EditIcon className="h-4 w-4"/></button>
                        <button onClick={() => handleDeleteItem(item)} className="text-gray-500 hover:text-red-600"><TrashIcon className="h-4 w-4"/></button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="flex justify-end space-x-4">
              <button onClick={handleCloseSlipModal} className="bg-gray-200 text-gray-800 py-2 px-4 rounded-lg font-semibold hover:bg-gray-300">Hủy</button>
              <button onClick={handleSaveSlip} disabled={weekConflict} className="bg-primary text-white py-2 px-4 rounded-lg font-semibold hover:bg-primary-dark disabled:bg-blue-300 disabled:cursor-not-allowed">Lưu</button>
            </div>
          </div>
        </div>
      )}

      {/* Item Add/Edit Modal */}
      {isItemModalOpen && editingSlipItem && (
        <div className="fixed inset-0 bg-black bg-opacity-60 flex justify-center items-center z-50">
          <div className="bg-white rounded-lg shadow-xl p-6 w-[95%] sm:w-full max-w-lg">
            <h2 className="text-xl font-bold mb-4">Thêm/Sửa Vật tư Xuất</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Vật tư</label>
                <select value={editingSlipItem.itemId} onChange={e => setEditingSlipItem({ ...editingSlipItem, itemId: e.target.value, costCode: '' })} className={`${formSelectStyle} ${itemErrors.itemId ? formInputErrorStyle : ''}`}>
                  <option value="">Chọn vật tư</option>
                  {items.map(item => <option key={item.id} value={item.id}>{item.name}</option>)}
                </select>
                 {itemErrors.itemId && <p className="text-red-500 text-xs mt-1">{itemErrors.itemId}</p>}
              </div>
               <div>
                <label className="block text-sm font-medium text-gray-700">Số lượng</label>
                <input type="number" value={editingSlipItem.quantity} onChange={e => setEditingSlipItem({ ...editingSlipItem, quantity: parseInt(e.target.value, 10) })} className={`mt-1 w-full ${formInputStyle} ${itemErrors.quantity ? formInputErrorStyle : ''}`} />
                {itemErrors.quantity && <p className="text-red-500 text-xs mt-1">{itemErrors.quantity}</p>}
              </div>
               <div>
                <label className="block text-sm font-medium text-gray-700">Phân hệ</label>
                <select value={editingSlipItem.subsystem} onChange={e => setEditingSlipItem({ ...editingSlipItem, subsystem: e.target.value, costCode: '' })} className={formSelectStyle}>
                    <option value="">Chọn phân hệ</option>
                    {subsystems.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Mục đích</label>
                    <select value={editingSlipItem.purpose || ''} onChange={e => setEditingSlipItem({ ...editingSlipItem, purpose: e.target.value, costCode: '' })} className={formSelectStyle}>
                      <option value="">Chọn mục đích</option>
                      {purposes.map(p => <option key={p} value={p}>{p}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Cách thực hiện</label>
                    <select value={editingSlipItem.method || ''} onChange={e => setEditingSlipItem({ ...editingSlipItem, method: e.target.value, costCode: '' })} className={formSelectStyle}>
                      <option value="">Chọn cách thực hiện</option>
                      {methods.map(m => <option key={m} value={m}>{m}</option>)}
                    </select>
                  </div>
              </div>
               <div>
                  <label className="block text-sm font-medium text-gray-700">Mã chi phí (tự động)</label>
                  <input type="text" value={editingSlipItem.costCode || ''} readOnly className={`mt-1 w-full ${formInputStyle} bg-gray-100`}/>
              </div>
               <div>
                <label className="block text-sm font-medium text-gray-700">Người xuất vật tư</label>
                <input type="text" value={editingSlipItem.handler} onChange={e => setEditingSlipItem({...editingSlipItem, handler: e.target.value})} placeholder="VD: Tổ đội 1, Anh Ba,..." className={`mt-1 w-full ${formInputStyle}`} />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Ghi chú</label>
                <textarea value={editingSlipItem.notes} onChange={e => setEditingSlipItem({...editingSlipItem, notes: e.target.value})} rows={2} className={formTextareaStyle}></textarea>
              </div>
            </div>
            <div className="flex justify-end space-x-4 mt-6">
              <button onClick={handleCloseItemModal} className="bg-gray-200 text-gray-800 py-2 px-4 rounded-lg font-semibold hover:bg-gray-300">Hủy</button>
              <button onClick={handleSaveItem} className="bg-primary text-white py-2 px-4 rounded-lg font-semibold hover:bg-primary-dark">Lưu</button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deletingSlipId && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
          <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-sm">
            <h2 className="text-xl font-bold mb-4">Xác nhận xóa</h2>
            <p className="text-gray-600 mb-6">Bạn có chắc chắn muốn xóa phiếu xuất này không? Hành động này không thể hoàn tác.</p>
            <div className="flex justify-end space-x-4">
              <button onClick={() => setDeletingSlipId(null)} className="bg-gray-200 text-gray-800 py-2 px-4 rounded-lg font-semibold hover:bg-gray-300">Hủy</button>
              <button onClick={() => handleDeleteSlip(deletingSlipId)} className="bg-red-600 text-white py-2 px-4 rounded-lg font-semibold hover:bg-red-700">Xóa</button>
            </div>
          </div>
        </div>
      )}

      {/* Complete Slip Modal */}
      {completingSlip && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
              <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-md">
                  <h2 className="text-xl font-bold mb-4">Hoàn thành Phiếu Xuất: {completingSlip.code}</h2>
                  <p className="text-gray-600 mb-4">Để hoàn thành phiếu, vui lòng tải lên biên bản hoàn thành công việc.</p>
                  
                  <div>
                      <label className="block w-full px-4 py-6 border-2 border-dashed border-gray-300 rounded-md text-center cursor-pointer hover:border-primary">
                          <span className="block text-primary font-semibold">
                              {completionFile ? completionFile.name : 'Chọn tệp biên bản'}
                          </span>
                          <input 
                              type="file" 
                              className="hidden" 
                              onChange={(e) => setCompletionFile(e.target.files ? e.target.files[0] : null)} 
                              accept=".pdf,.doc,.docx,.jpg,.png"
                          />
                      </label>
                      {completionFile && (
                          <button 
                              onClick={() => setCompletionFile(null)}
                              className="text-sm text-red-500 hover:underline mt-2"
                          >
                              Xóa tệp
                          </button>
                      )}
                  </div>

                  <div className="flex justify-end space-x-4 mt-6">
                      <button 
                          onClick={handleCloseCompleteModal} 
                          className="bg-gray-200 text-gray-800 py-2 px-4 rounded-lg font-semibold hover:bg-gray-300"
                      >
                          Hủy
                      </button>
                      <button 
                          onClick={handleCompleteSlip} 
                          disabled={!completionFile}
                          className="bg-secondary text-white py-2 px-4 rounded-lg font-semibold hover:bg-green-600 disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center"
                      >
                          <CheckCircleIcon className="inline mr-2 h-5 w-5"/>
                          Hoàn thành
                      </button>
                  </div>
              </div>
          </div>
      )}

    </div>
  );
};

const RequisitionsPage: React.FC<{
  requisitions: Requisition[];
  setRequisitions: React.Dispatch<React.SetStateAction<Requisition[]>>;
  items: Item[];
  itemMap: Map<string, Item>;
  requisitionTypes: RequisitionType[];
  subsystems: Subsystem[];
  costCodes: CostCode[];
  addLog: (action: string, details: string) => void;
  currentUser: User;
}> = ({ requisitions, setRequisitions, items, itemMap, requisitionTypes, subsystems, costCodes, addLog, currentUser }) => {

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingReq, setEditingReq] = useState<Requisition | null>(null);
  const [isItemModalOpen, setIsItemModalOpen] = useState(false);
  const [editingReqItem, setEditingReqItem] = useState<RequisitionItem | null>(null);
  const [deletingReqId, setDeletingReqId] = useState<string | null>(null);
  const [viewingReq, setViewingReq] = useState<Requisition | null>(null);

  const canManage = currentUser.permissions.includes('manage_requisitions');
  const canApprove = currentUser.permissions.includes('approve_requisitions');

  const purposes = useMemo(() => [...new Set(costCodes.map(c => c.purpose))], [costCodes]);
  const methods = useMemo(() => [...new Set(costCodes.map(c => c.method))], [costCodes]);
  
  useEffect(() => {
    if (!editingReqItem || !editingReqItem.itemId || !editingReqItem.subsystem || !editingReqItem.purpose || !editingReqItem.method) {
        if (editingReqItem && editingReqItem.costCode) {
            setEditingReqItem(prev => ({ ...prev!, costCode: '' }));
        }
        return;
    }

    const item = itemMap.get(editingReqItem.itemId);
    if (!item) return;

    const foundCostCode = costCodes.find(cc =>
        cc.classification === item.category &&
        cc.subsystem === editingReqItem.subsystem &&
        cc.purpose === editingReqItem.purpose &&
        cc.method === editingReqItem.method
    );

    const newCostCode = foundCostCode ? foundCostCode.code : '';
    if (newCostCode !== editingReqItem.costCode) {
        setEditingReqItem(prev => ({ ...prev!, costCode: newCostCode }));
    }
  }, [editingReqItem?.itemId, editingReqItem?.subsystem, editingReqItem?.purpose, editingReqItem?.method, itemMap, costCodes, editingReqItem]);

  const getStatusColor = (status: RequisitionStatus) => {
    switch (status) {
      case RequisitionStatus.Approved: return 'bg-green-100 text-green-800';
      case RequisitionStatus.New: return 'bg-blue-100 text-blue-800';
      case RequisitionStatus.Rejected: return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const handleOpenModal = (req: Requisition | null = null) => {
    if (!canManage) return;
    if (req) {
      setEditingReq({ ...req, items: [...req.items] });
    } else {
      const newReqCode = `TT-${String(requisitions.length + 1).padStart(3, '0')}`;
      setEditingReq({
        id: `req-${Date.now()}`,
        code: newReqCode,
        createdBy: currentUser.fullName,
        date: new Date().toISOString().split('T')[0],
        type: '',
        purpose: '',
        status: RequisitionStatus.New,
        notes: '',
        items: [],
      });
    }
    setIsModalOpen(true);
  };
  
  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingReq(null);
  };
  
  const handleSaveReq = () => {
    if (!editingReq) return;
    const isEditing = requisitions.some(r => r.id === editingReq.id);
    if(isEditing) {
      setRequisitions(requisitions.map(r => r.id === editingReq.id ? editingReq : r));
      addLog('Cập nhật Tờ trình', `Mã TT: ${editingReq.code}`);
    } else {
      setRequisitions([...requisitions, editingReq]);
      addLog('Tạo Tờ trình', `Mã TT: ${editingReq.code}`);
    }
    handleCloseModal();
  };
  
  const handleDeleteReq = (id: string) => {
    const reqToDelete = requisitions.find(r => r.id === id);
    if (reqToDelete) {
      addLog('Xóa Tờ trình', `Mã TT: ${reqToDelete.code}`);
      setRequisitions(requisitions.filter(r => r.id !== id));
    }
    setDeletingReqId(null);
  };
  
  const handleOpenItemModal = (item: RequisitionItem | null) => {
    setEditingReqItem(item ? {...item} : {
      id: `req-item-${Date.now()}`,
      itemId: '',
      requestedQuantity: 1,
      receivedQuantity: 0,
      itemStatus: RequisitionItemStatus.Pending,
      subsystem: '',
      method: '',
      purpose: '',
      costCode: '',
      notes: '',
    });
    setIsItemModalOpen(true);
  };

  const handleCloseItemModal = () => {
    setIsItemModalOpen(false);
    setEditingReqItem(null);
  };

  const handleSaveItem = () => {
    if(editingReq && editingReqItem) {
      const newItems = [...editingReq.items];
      const existingIndex = newItems.findIndex(i => i.id === editingReqItem.id);
      if(existingIndex > -1) {
        newItems[existingIndex] = editingReqItem;
      } else {
        newItems.push(editingReqItem);
      }
      setEditingReq({ ...editingReq, items: newItems });
      handleCloseItemModal();
    }
  };

  const handleDeleteItem = (itemToDelete: RequisitionItem) => {
    if(editingReq) {
      setEditingReq({
        ...editingReq,
        items: editingReq.items.filter(i => i.id !== itemToDelete.id)
      });
    }
  };

  const handleChangeStatus = (id: string, status: RequisitionStatus) => {
    setRequisitions(requisitions.map(r => r.id === id ? { ...r, status } : r));
    const req = requisitions.find(r => r.id === id);
    if (req) {
       addLog(`Cập nhật trạng thái Tờ trình`, `Mã TT: ${req.code}, Trạng thái mới: ${status}`);
    }
  };

  const formInputStyle = "mt-1 p-2 border rounded w-full bg-white text-dark-text focus:ring-1 focus:ring-primary focus:border-primary transition-shadow";
  const formSelectStyle = "mt-1 p-2 border rounded w-full bg-white text-dark-text focus:ring-1 focus:ring-primary focus:border-primary transition-shadow";
  const formTextareaStyle = "mt-1 p-2 border rounded w-full bg-white text-dark-text focus:ring-1 focus:ring-primary focus:border-primary transition-shadow";

  return (
    <div>
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 mb-6">
        <h1 className="text-3xl font-bold">Quản lý Tờ trình</h1>
        {canManage && (
          <button onClick={() => handleOpenModal()} className="bg-primary text-white py-2 px-4 rounded-lg font-semibold hover:bg-primary-dark flex items-center transition-colors">
              <PlusIcon className="mr-2" />
              Thêm Tờ trình
          </button>
        )}
      </div>
      <div className="bg-white p-4 rounded-lg shadow overflow-x-auto">
        <table className="w-full min-w-max">
          <thead>
            <tr className="text-left text-sm font-semibold text-gray-600 border-b bg-gray-50">
              <th className="p-3">Mã TT</th>
              <th className="p-3">Ngày</th>
              <th className="p-3">Người tạo</th>
              <th className="p-3">Loại</th>
              <th className="p-3">Mục đích</th>
              <th className="p-3">Trạng thái</th>
              <th className="p-3 text-center">Hành động</th>
            </tr>
          </thead>
          <tbody>
            {requisitions.map(req => (
              <tr key={req.id} className="border-b hover:bg-gray-50 text-sm">
                <td className="p-3 font-medium">{req.code}</td>
                <td className="p-3">{req.date}</td>
                <td className="p-3">{req.createdBy}</td>
                <td className="p-3">{req.type}</td>
                <td className="p-3">{req.purpose}</td>
                <td className="p-3">
                  <span className={`px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(req.status)}`}>
                    {req.status}
                  </span>
                </td>
                 <td className="p-3 flex justify-center items-center space-x-2">
                    <button onClick={() => setViewingReq(req)} className="text-gray-500 hover:text-blue-600" title="Xem"><EyeIcon /></button>
                    {req.status === RequisitionStatus.New && (
                        <>
                            {canManage && (
                              <>
                                <button onClick={() => handleOpenModal(req)} className="text-gray-500 hover:text-green-600" title="Sửa"><EditIcon /></button>
                                <button onClick={() => setDeletingReqId(req.id)} className="text-gray-500 hover:text-red-600" title="Xóa"><TrashIcon /></button>
                              </>
                            )}
                            {canApprove && (
                              <>
                                <button onClick={() => handleChangeStatus(req.id, RequisitionStatus.Approved)} className="text-gray-500 hover:text-secondary" title="Duyệt"><CheckCircleIcon /></button>
                                <button onClick={() => handleChangeStatus(req.id, RequisitionStatus.Rejected)} className="text-gray-500 hover:text-red-500" title="Từ chối"><XIcon /></button>
                              </>
                            )}
                        </>
                    )}
                 </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

       {viewingReq && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
            <div className="bg-white rounded-lg shadow-2xl p-6 sm:p-8 w-[95%] sm:w-full max-w-3xl max-h-[90vh] flex flex-col">
                 <div className="flex justify-between items-center border-b pb-4 mb-6">
                    <h2 className="text-2xl font-bold text-gray-800">Chi tiết Tờ trình: {viewingReq.code}</h2>
                    <button onClick={() => setViewingReq(null)} className="text-gray-500 hover:text-gray-800"><XIcon className="h-6 w-6" /></button>
                </div>
                 <div className="grid grid-cols-2 gap-4 mb-6 text-sm">
                    <div><span className="font-semibold text-gray-500">Mã TT:</span> {viewingReq.code}</div>
                    <div><span className="font-semibold text-gray-500">Ngày:</span> {viewingReq.date}</div>
                    <div><span className="font-semibold text-gray-500">Người tạo:</span> {viewingReq.createdBy}</div>
                    <div><span className="font-semibold text-gray-500">Loại:</span> {viewingReq.type}</div>
                    <div className="col-span-2"><span className="font-semibold text-gray-500">Mục đích:</span> {viewingReq.purpose}</div>
                    <div className="col-span-2"><span className="font-semibold text-gray-500">Ghi chú:</span> {viewingReq.notes || '-'}</div>
                </div>
                <h3 className="text-lg font-bold text-gray-700 border-t pt-4 mb-4">Chi tiết vật tư yêu cầu</h3>
                <div className="overflow-y-auto flex-grow">
                     <table className="w-full text-sm">
                        <thead><tr className="text-left font-semibold text-gray-600 bg-gray-50"><th className="p-2">Vật tư</th><th className="p-2 text-right">SL Yêu cầu</th><th className="p-2 text-right">SL Đã nhận</th><th className="p-2">Mã chi phí</th><th className="p-2">Trạng thái</th></tr></thead>
                        <tbody>
                            {viewingReq.items.map(item => (
                                <tr key={item.id} className="border-b">
                                    <td className="p-2 font-medium">{itemMap.get(item.itemId)?.name}</td>
                                    <td className="p-2 text-right">{item.requestedQuantity}</td>
                                    <td className="p-2 text-right">{item.receivedQuantity}</td>
                                    <td className="p-2">{item.costCode}</td>
                                    <td className="p-2">{item.itemStatus}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
                 <div className="mt-6 pt-4 border-t flex justify-end space-x-4">
                    <button onClick={() => exportRequisitionToExcel(viewingReq, itemMap, currentUser)} className="bg-secondary text-white py-2 px-6 rounded-lg font-semibold hover:bg-green-600 flex items-center">
                      <DownloadIcon className="mr-2" />
                      Xuất Excel
                    </button>
                    <button onClick={() => setViewingReq(null)} className="bg-gray-200 text-gray-800 py-2 px-6 rounded-lg font-semibold hover:bg-gray-300">Đóng</button>
                </div>
            </div>
        </div>
       )}
       
       {isModalOpen && editingReq && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
            <div className="bg-white rounded-lg shadow-xl p-6 w-[95%] sm:w-full max-w-3xl max-h-[90vh] flex flex-col">
                <h2 className="text-xl font-bold mb-4">{requisitions.some(r => r.id === editingReq.id) ? 'Sửa Tờ trình' : 'Thêm Tờ trình'}</h2>
                 <div className="grid grid-cols-2 gap-4 mb-4">
                    <input type="text" value={editingReq.code} onChange={e => setEditingReq({...editingReq, code: e.target.value})} placeholder="Mã tờ trình" className={formInputStyle}/>
                    <input type="date" value={editingReq.date} onChange={e => setEditingReq({...editingReq, date: e.target.value})} className={formInputStyle}/>
                    <input type="text" value={editingReq.createdBy} onChange={e => setEditingReq({...editingReq, createdBy: e.target.value})} placeholder="Người tạo" className={formInputStyle}/>
                    <select value={editingReq.type} onChange={e => setEditingReq({...editingReq, type: e.target.value})} className={formSelectStyle}>
                        <option value="">Chọn loại tờ trình</option>
                        {requisitionTypes.map(t => <option key={t} value={t}>{t}</option>)}
                    </select>
                    <input type="text" value={editingReq.purpose} onChange={e => setEditingReq({...editingReq, purpose: e.target.value})} placeholder="Mục đích" className={`${formInputStyle} col-span-2`}/>
                    <textarea value={editingReq.notes} onChange={e => setEditingReq({...editingReq, notes: e.target.value})} placeholder="Ghi chú" rows={2} className={`${formTextareaStyle} col-span-2`}></textarea>
                 </div>
                 <div className="flex justify-between items-center mb-2">
                    <h3 className="font-semibold">Danh sách vật tư</h3>
                    <button onClick={() => handleOpenItemModal(null)} className="bg-secondary text-white text-sm py-1 px-3 rounded-md hover:bg-green-600 flex items-center"><PlusIcon className="mr-1 h-4 w-4" />Thêm vật tư</button>
                </div>
                <div className="border rounded-md overflow-y-auto flex-grow mb-4">
                    <table className="w-full text-sm">
                        <thead className="bg-gray-50"><tr><th className="p-2 text-left">Vật tư</th><th className="p-2 text-right">Số lượng</th><th className="p-2 text-center">Hành động</th></tr></thead>
                        <tbody>
                            {editingReq.items.map(item => (
                                <tr key={item.id} className="border-t">
                                    <td className="p-2">{itemMap.get(item.itemId)?.name}</td>
                                    <td className="p-2 text-right">{item.requestedQuantity}</td>
                                    <td className="p-2 flex justify-center items-center space-x-2">
                                        <button onClick={() => handleOpenItemModal(item)} className="text-gray-500 hover:text-green-600"><EditIcon className="h-4 w-4"/></button>
                                        <button onClick={() => handleDeleteItem(item)} className="text-gray-500 hover:text-red-600"><TrashIcon className="h-4 w-4"/></button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
                <div className="flex justify-end space-x-4">
                    <button onClick={handleCloseModal} className="bg-gray-200 text-gray-800 py-2 px-4 rounded-lg">Hủy</button>
                    <button onClick={handleSaveReq} className="bg-primary text-white py-2 px-4 rounded-lg">Lưu</button>
                </div>
            </div>
        </div>
       )}

        {isItemModalOpen && editingReqItem && (
             <div className="fixed inset-0 bg-black bg-opacity-60 flex justify-center items-center z-50">
                <div className="bg-white rounded-lg shadow-xl p-6 w-[95%] sm:w-full max-w-lg">
                    <h2 className="text-xl font-bold mb-4">Thêm/Sửa Vật tư Yêu cầu</h2>
                     <div className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block text-sm font-medium">Vật tư</label>
                                <select value={editingReqItem.itemId} onChange={e => setEditingReqItem({ ...editingReqItem, itemId: e.target.value, costCode: '' })} className={formSelectStyle}>
                                    <option value="">Chọn vật tư</option>
                                    {items.map(item => <option key={item.id} value={item.id}>{item.name}</option>)}
                                </select>
                            </div>
                            <div>
                                <label className="block text-sm font-medium">Số lượng yêu cầu</label>
                                <input type="number" value={editingReqItem.requestedQuantity} onChange={e => setEditingReqItem({ ...editingReqItem, requestedQuantity: parseInt(e.target.value, 10) || 0 })} className={formInputStyle}/>
                            </div>
                        </div>
                        <div>
                            <label className="block text-sm font-medium">Phân hệ</label>
                            <select value={editingReqItem.subsystem} onChange={e => setEditingReqItem({ ...editingReqItem, subsystem: e.target.value, costCode: '' })} className={formSelectStyle}>
                                <option value="">Chọn phân hệ</option>
                                {subsystems.map(s => <option key={s} value={s}>{s}</option>)}
                            </select>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                           <div>
                              <label className="block text-sm font-medium">Mục đích</label>
                              <select value={editingReqItem.purpose} onChange={e => setEditingReqItem({ ...editingReqItem, purpose: e.target.value, costCode: '' })} className={formSelectStyle}>
                                  <option value="">Chọn mục đích</option>
                                  {purposes.map(p => <option key={p} value={p}>{p}</option>)}
                              </select>
                            </div>
                            <div>
                                <label className="block text-sm font-medium">Cách thực hiện</label>
                                <select value={editingReqItem.method} onChange={e => setEditingReqItem({ ...editingReqItem, method: e.target.value, costCode: '' })} className={formSelectStyle}>
                                  <option value="">Chọn cách thực hiện</option>
                                  {methods.map(m => <option key={m} value={m}>{m}</option>)}
                                </select>
                            </div>
                        </div>
                        <div>
                            <label className="block text-sm font-medium">Mã chi phí (tự động)</label>
                            <input type="text" value={editingReqItem.costCode} readOnly className={`${formInputStyle} bg-gray-100`}/>
                        </div>
                        <div>
                            <label className="block text-sm font-medium">Ghi chú</label>
                            <textarea value={editingReqItem.notes} onChange={e => setEditingReqItem({ ...editingReqItem, notes: e.target.value })} rows={2} className={formTextareaStyle}></textarea>
                        </div>
                    </div>
                     <div className="flex justify-end space-x-4 mt-6">
                        <button onClick={handleCloseItemModal} className="bg-gray-200 text-gray-800 py-2 px-4 rounded-lg">Hủy</button>
                        <button onClick={handleSaveItem} className="bg-primary text-white py-2 px-4 rounded-lg">Lưu</button>
                    </div>
                </div>
             </div>
        )}

      {deletingReqId && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
          <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-sm">
            <h2 className="text-xl font-bold mb-4">Xác nhận xóa</h2>
            <p className="text-gray-600 mb-6">Bạn có chắc chắn muốn xóa tờ trình này? Hành động này không thể hoàn tác.</p>
            <div className="flex justify-end space-x-4">
              <button onClick={() => setDeletingReqId(null)} className="bg-gray-200 text-gray-800 py-2 px-4 rounded-lg">Hủy</button>
              <button onClick={() => handleDeleteReq(deletingReqId)} className="bg-red-600 text-white py-2 px-4 rounded-lg">Xóa</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const SettingsPage: React.FC<{
  categories: Category[]; setCategories: React.Dispatch<React.SetStateAction<Category[]>>;
  subsystems: Subsystem[]; setSubsystems: React.Dispatch<React.SetStateAction<Subsystem[]>>;
  costCodes: CostCode[]; setCostCodes: React.Dispatch<React.SetStateAction<CostCode[]>>;
  requisitionTypes: RequisitionType[]; setRequisitionTypes: React.Dispatch<React.SetStateAction<RequisitionType[]>>;
  addLog: (action: string, details: string) => void;
  currentUser: User;
}> = ({ categories, setCategories, subsystems, setSubsystems, costCodes, setCostCodes, requisitionTypes, setRequisitionTypes, addLog, currentUser }) => {
  type Tab = 'categories' | 'subsystems' | 'costCodes' | 'requisitionTypes';
  const [activeTab, setActiveTab] = useState<Tab>('categories');

  const canManage = currentUser.permissions.includes('manage_settings');
  const [isCostCodeModalOpen, setIsCostCodeModalOpen] = useState(false);
  const [editingCostCode, setEditingCostCode] = useState<CostCode | null>(null);

  const formInputStyle = "mt-1 p-2 border rounded w-full bg-white text-dark-text focus:ring-1 focus:ring-primary focus:border-primary transition-shadow";
  const formSelectStyle = "mt-1 p-2 border rounded w-full bg-white text-dark-text focus:ring-1 focus:ring-primary focus:border-primary transition-shadow";

  const tabs: { key: Tab; label: string }[] = [
    { key: 'categories', label: 'Loại vật tư' },
    { key: 'subsystems', label: 'Phân hệ' },
    { key: 'costCodes', label: 'Mã chi phí' },
    { key: 'requisitionTypes', label: 'Loại tờ trình' },
  ];

  const renderContent = () => {
    switch (activeTab) {
      case 'categories': return (
        <SimpleManager 
          title="Loại vật tư"
          items={categories}
          setItems={setCategories}
          addLog={addLog}
          logEntity="Loại vật tư"
          canManage={canManage}
        />
      );
      case 'subsystems': return (
         <SimpleManager 
          title="Phân hệ"
          items={subsystems}
          setItems={setSubsystems}
          addLog={addLog}
          logEntity="Phân hệ"
          canManage={canManage}
        />
      );
      case 'requisitionTypes': return (
         <SimpleManager 
          title="Loại tờ trình"
          items={requisitionTypes}
          setItems={setRequisitionTypes}
          addLog={addLog}
          logEntity="Loại tờ trình"
          canManage={canManage}
        />
      );
      case 'costCodes': return (
        <div>
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-bold">Quản lý Mã chi phí</h2>
            {canManage && (
              <button onClick={() => { setEditingCostCode({ id: `cc-${Date.now()}`, classification: '', subsystem: '', purpose: '', method: '', code: '' }); setIsCostCodeModalOpen(true); }} className="bg-primary text-white py-2 px-4 rounded-lg font-semibold hover:bg-primary-dark flex items-center">
                <PlusIcon className="mr-2" /> Thêm Mã chi phí
              </button>
            )}
          </div>
          <div className="overflow-x-auto">
            <table className="w-full min-w-max text-sm">
              <thead><tr className="text-left font-semibold text-gray-600 bg-gray-50"><th className="p-2">Mã</th><th className="p-2">Phân loại</th><th className="p-2">Phân hệ</th><th className="p-2">Mục đích</th><th className="p-2">Cách thực hiện</th>{canManage && <th className="p-2 text-center">Hành động</th>}</tr></thead>
              <tbody>
                {costCodes.map(cc => (
                  <tr key={cc.id} className="border-b">
                    <td className="p-2 font-medium">{cc.code}</td>
                    <td className="p-2">{cc.classification}</td>
                    <td className="p-2">{cc.subsystem}</td>
                    <td className="p-2">{cc.purpose}</td>
                    <td className="p-2">{cc.method}</td>
                    {canManage && (
                      <td className="p-2 flex justify-center items-center space-x-2">
                        <button onClick={() => { setEditingCostCode(cc); setIsCostCodeModalOpen(true); }} className="text-gray-500 hover:text-green-600"><EditIcon/></button>
                        <button onClick={() => { setCostCodes(costCodes.filter(c => c.id !== cc.id)); addLog('Xóa Mã chi phí', `Mã: ${cc.code}`); }} className="text-gray-500 hover:text-red-600"><TrashIcon/></button>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      );
    }
  };

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Cài đặt</h1>
      <div className="flex border-b mb-6 overflow-x-auto">
        {tabs.map(tab => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={`py-2 px-4 font-semibold whitespace-nowrap ${activeTab === tab.key ? 'border-b-2 border-primary text-primary' : 'text-gray-500 hover:text-gray-700'}`}
          >
            {tab.label}
          </button>
        ))}
      </div>
      <div className="bg-white p-6 rounded-lg shadow">
        {renderContent()}
         {!canManage && activeTab !== 'costCodes' && <p className="text-gray-500 text-sm mt-4">Bạn không có quyền chỉnh sửa cài đặt này.</p>}
      </div>

       {isCostCodeModalOpen && editingCostCode && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
          <div className="bg-white rounded-lg shadow-xl p-6 w-[95%] sm:w-full max-w-lg">
            <h2 className="text-xl font-bold mb-4">Thêm/Sửa Mã chi phí</h2>
            <div className="space-y-4">
              <input type="text" placeholder="Mã chi phí" value={editingCostCode.code} onChange={e => setEditingCostCode({...editingCostCode, code: e.target.value})} className={formInputStyle} />
              <select value={editingCostCode.classification} onChange={e => setEditingCostCode({...editingCostCode, classification: e.target.value})} className={formSelectStyle}>
                <option value="">Chọn phân loại</option>
                {categories.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
              <select value={editingCostCode.subsystem} onChange={e => setEditingCostCode({...editingCostCode, subsystem: e.target.value})} className={formSelectStyle}>
                <option value="">Chọn phân hệ</option>
                {subsystems.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
              <input type="text" placeholder="Mục đích" value={editingCostCode.purpose} onChange={e => setEditingCostCode({...editingCostCode, purpose: e.target.value})} className={formInputStyle} />
              <input type="text" placeholder="Cách thực hiện" value={editingCostCode.method} onChange={e => setEditingCostCode({...editingCostCode, method: e.target.value})} className={formInputStyle} />
            </div>
            <div className="flex justify-end space-x-4 mt-6">
              <button onClick={() => setIsCostCodeModalOpen(false)} className="bg-gray-200 text-gray-800 py-2 px-4 rounded-lg">Hủy</button>
              <button onClick={() => {
                const isEditing = costCodes.some(c => c.id === editingCostCode.id);
                if (isEditing) {
                  setCostCodes(costCodes.map(c => c.id === editingCostCode.id ? editingCostCode : c));
                   addLog('Cập nhật Mã chi phí', `Mã: ${editingCostCode.code}`);
                } else {
                  setCostCodes([...costCodes, editingCostCode]);
                   addLog('Tạo Mã chi phí', `Mã: ${editingCostCode.code}`);
                }
                setIsCostCodeModalOpen(false);
              }} className="bg-primary text-white py-2 px-4 rounded-lg">Lưu</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};


const SimpleManager: React.FC<{
  title: string;
  items: string[];
  setItems: React.Dispatch<React.SetStateAction<string[]>>;
  addLog: (action: string, details: string) => void;
  logEntity: string;
  canManage: boolean;
}> = ({ title, items, setItems, addLog, logEntity, canManage }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState('');
  const [originalItem, setOriginalItem] = useState<string | null>(null);

  const handleSave = () => {
    if (originalItem) { // Editing
      setItems(items.map(i => i === originalItem ? editingItem : i));
      addLog(`Cập nhật ${logEntity}`, `Tên mới: ${editingItem}`);
    } else { // Adding
      setItems([...items, editingItem]);
       addLog(`Tạo ${logEntity}`, `Tên: ${editingItem}`);
    }
    setIsModalOpen(false);
  };
  
  const handleDelete = (item: string) => {
     setItems(items.filter(i => i !== item));
     addLog(`Xóa ${logEntity}`, `Tên: ${item}`);
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold">{`Quản lý ${title}`}</h2>
        {canManage && (
          <button onClick={() => { setEditingItem(''); setOriginalItem(null); setIsModalOpen(true); }} className="bg-primary text-white py-2 px-4 rounded-lg font-semibold hover:bg-primary-dark flex items-center">
            <PlusIcon className="mr-2" /> {`Thêm ${title}`}
          </button>
        )}
      </div>
      <div className="overflow-x-auto">
        <table className="w-full min-w-max text-sm">
          <thead><tr className="text-left font-semibold text-gray-600 bg-gray-50"><th className="p-2">Tên</th>{canManage && <th className="p-2 text-center">Hành động</th>}</tr></thead>
          <tbody>
            {items.map(item => (
              <tr key={item} className="border-b">
                <td className="p-2">{item}</td>
                {canManage && (
                  <td className="p-2 flex justify-center items-center space-x-2">
                    <button onClick={() => { setEditingItem(item); setOriginalItem(item); setIsModalOpen(true); }} className="text-gray-500 hover:text-green-600"><EditIcon/></button>
                    <button onClick={() => handleDelete(item)} className="text-gray-500 hover:text-red-600"><TrashIcon/></button>
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
          <div className="bg-white rounded-lg shadow-xl p-6 w-[95%] sm:w-full max-w-md">
            <h2 className="text-xl font-bold mb-4">{originalItem ? `Sửa ${title}`: `Thêm ${title}`}</h2>
            <input type="text" value={editingItem} onChange={e => setEditingItem(e.target.value)} className="p-2 border rounded w-full bg-white text-dark-text focus:ring-1 focus:ring-primary focus:border-primary transition-shadow" />
            <div className="flex justify-end space-x-4 mt-6">
              <button onClick={() => setIsModalOpen(false)} className="bg-gray-200 text-gray-800 py-2 px-4 rounded-lg">Hủy</button>
              <button onClick={handleSave} className="bg-primary text-white py-2 px-4 rounded-lg">Lưu</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};


const LogPage: React.FC<{ logs: LogEntry[] }> = ({ logs }) => {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Nhật ký Hoạt động</h1>
      <div className="bg-white p-4 rounded-lg shadow overflow-x-auto">
        {logs.length > 0 ? (
          <table className="w-full min-w-max">
            <thead>
              <tr className="text-left text-sm font-semibold text-gray-600 border-b bg-gray-50">
                <th className="p-3">Thời gian</th>
                <th className="p-3">Người dùng</th>
                <th className="p-3">Hành động</th>
                <th className="p-3">Chi tiết</th>
              </tr>
            </thead>
            <tbody>
              {logs.map(log => (
                <tr key={log.id} className="border-b hover:bg-gray-50 text-sm">
                  <td className="p-3">{log.timestamp}</td>
                  <td className="p-3">{log.user}</td>
                  <td className="p-3 font-medium">{log.action}</td>
                  <td className="p-3">{log.details}</td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <p className="text-gray-500 p-4 text-center">Chưa có hoạt động nào được ghi nhận.</p>
        )}
      </div>
    </div>
  );
};

const UsersPage: React.FC<{
  users: User[];
  setUsers: React.Dispatch<React.SetStateAction<User[]>>;
  addLog: (action: string, details: string) => void;
  currentUser: User;
}> = ({ users, setUsers, addLog, currentUser }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [deletingUserId, setDeletingUserId] = useState<string | null>(null);
  const [togglingStatusUser, setTogglingStatusUser] = useState<User | null>(null);

  const canManage = currentUser.permissions.includes('manage_users');

  const handleOpenModal = (user: User | null = null) => {
    if (!canManage) return;
    if (user) {
      setEditingUser({ ...user });
    } else {
      setEditingUser({
        id: `user-${Date.now()}`,
        username: '',
        password: '',
        fullName: '',
        title: '',
        phone: '',
        role: UserRole.Staff,
        permissions: [],
        status: 'Hoạt động',
      });
    }
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingUser(null);
  };

  const handleSaveUser = (userToSave: User) => {
    const isEditing = users.some(u => u.id === userToSave.id);
    if (isEditing) {
      setUsers(users.map(u => u.id === userToSave.id ? userToSave : u));
      addLog('Cập nhật Người dùng', `Tên: ${userToSave.fullName}`);
    } else {
      setUsers([...users, userToSave]);
      addLog('Tạo Người dùng', `Tên: ${userToSave.fullName}`);
    }
    handleCloseModal();
  };
  
  const handleDeleteUser = (id: string) => {
    const userToDelete = users.find(u => u.id === id);
    if(userToDelete) {
        addLog('Xóa Người dùng', `Tên: ${userToDelete.fullName}`);
        setUsers(users.filter(u => u.id !== id));
    }
    setDeletingUserId(null);
  };

  const handleToggleStatus = () => {
    if(!togglingStatusUser) return;
    const newStatus = togglingStatusUser.status === 'Hoạt động' ? 'Đóng băng' : 'Hoạt động';
    setUsers(users.map(u => u.id === togglingStatusUser.id ? { ...u, status: newStatus } : u));
    addLog('Thay đổi trạng thái Người dùng', `Tên: ${togglingStatusUser.fullName}, Trạng thái mới: ${newStatus}`);
    setTogglingStatusUser(null);
  }

  const getStatusColor = (status: UserStatus) => {
    return status === 'Hoạt động' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800';
  };

  return (
    <div>
      <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4 mb-6">
        <h1 className="text-3xl font-bold">Quản lý Người dùng</h1>
        {canManage && (
          <button onClick={() => handleOpenModal()} className="bg-primary text-white py-2 px-4 rounded-lg font-semibold hover:bg-primary-dark flex items-center transition-colors">
            <PlusIcon className="mr-2" />
            Thêm Người dùng
          </button>
        )}
      </div>
      <div className="bg-white p-4 rounded-lg shadow overflow-x-auto">
        <table className="w-full min-w-max">
          <thead>
            <tr className="text-left text-sm font-semibold text-gray-600 border-b bg-gray-50">
              <th className="p-3">Họ và tên</th>
              <th className="p-3">Tên đăng nhập</th>
              <th className="p-3">Chức danh</th>
              <th className="p-3">Vai trò</th>
              <th className="p-3">Trạng thái</th>
              {canManage && <th className="p-3 text-center">Hành động</th>}
            </tr>
          </thead>
          <tbody>
            {users.map(user => (
              <tr key={user.id} className="border-b hover:bg-gray-50 text-sm">
                <td className="p-3 font-medium">{user.fullName}</td>
                <td className="p-3">{user.username}</td>
                <td className="p-3">{user.title}</td>
                <td className="p-3">{user.role}</td>
                <td className="p-3">
                  <span className={`px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(user.status)}`}>
                    {user.status}
                  </span>
                </td>
                {canManage && (
                  <td className="p-3 flex justify-center items-center space-x-2">
                    <button onClick={() => handleOpenModal(user)} className="text-gray-500 hover:text-green-600" title="Sửa"><EditIcon /></button>
                    {user.status === 'Hoạt động' ? (
                      <button onClick={() => setTogglingStatusUser(user)} className="text-gray-500 hover:text-yellow-600" title="Đóng băng"><UserXIcon /></button>
                    ) : (
                      <button onClick={() => setTogglingStatusUser(user)} className="text-gray-500 hover:text-green-600" title="Kích hoạt"><UserCheckIcon /></button>
                    )}
                    <button onClick={() => setDeletingUserId(user.id)} className="text-gray-500 hover:text-red-600" title="Xóa"><TrashIcon /></button>
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
       {isModalOpen && editingUser && (
        <UserFormModal
          user={editingUser}
          isEditing={users.some(u => u.id === editingUser.id)}
          onClose={handleCloseModal}
          onSave={handleSaveUser}
        />
      )}
       {deletingUserId && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
          <div className="bg-white rounded-lg shadow-xl p-6 w-[95%] sm:w-full max-w-sm">
            <h2 className="text-xl font-bold mb-4">Xác nhận xóa</h2>
            <p className="text-gray-600 mb-6">Bạn có chắc chắn muốn xóa người dùng này? Hành động này không thể hoàn tác.</p>
            <div className="flex justify-end space-x-4">
              <button onClick={() => setDeletingUserId(null)} className="bg-gray-200 text-gray-800 py-2 px-4 rounded-lg font-semibold hover:bg-gray-300">Hủy</button>
              <button onClick={() => handleDeleteUser(deletingUserId)} className="bg-red-600 text-white py-2 px-4 rounded-lg font-semibold hover:bg-red-700">Xóa</button>
            </div>
          </div>
        </div>
      )}
       {togglingStatusUser && (
         <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
          <div className="bg-white rounded-lg shadow-xl p-6 w-[95%] sm:w-full max-w-sm">
            <h2 className="text-xl font-bold mb-4">Xác nhận thay đổi</h2>
            <p className="text-gray-600 mb-6">{`Bạn có chắc chắn muốn ${togglingStatusUser.status === 'Hoạt động' ? 'đóng băng' : 'kích hoạt'} người dùng "${togglingStatusUser.fullName}"?`}</p>
            <div className="flex justify-end space-x-4">
              <button onClick={() => setTogglingStatusUser(null)} className="bg-gray-200 text-gray-800 py-2 px-4 rounded-lg font-semibold hover:bg-gray-300">Hủy</button>
              <button onClick={handleToggleStatus} className="bg-primary text-white py-2 px-4 rounded-lg font-semibold hover:bg-primary-dark">Xác nhận</button>
            </div>
          </div>
        </div>
       )}
    </div>
  );
};


const UserFormModal: React.FC<{
  user: User;
  isEditing: boolean;
  onClose: () => void;
  onSave: (user: User) => void;
}> = ({ user, isEditing, onClose, onSave }) => {
    const [currentUser, setCurrentUser] = useState<User>(user);
    const [selectedPermissions, setSelectedPermissions] = useState<Set<Permission>>(new Set(user.permissions));

    const handlePermissionChange = (permission: Permission, isChecked: boolean) => {
        const newPermissions = new Set(selectedPermissions);
        if (isChecked) {
            newPermissions.add(permission);
        } else {
            newPermissions.delete(permission);
        }
        setSelectedPermissions(newPermissions);
    };

    const handleSave = () => {
        onSave({ ...currentUser, permissions: Array.from(selectedPermissions) });
    };

    const formInputStyle = "mt-1 p-2 border rounded w-full bg-white text-dark-text focus:ring-1 focus:ring-primary focus:border-primary transition-shadow";
    const formSelectStyle = "mt-1 p-2 border rounded w-full bg-white text-dark-text focus:ring-1 focus:ring-primary focus:border-primary transition-shadow";

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
            <div className="bg-white rounded-lg shadow-xl p-6 w-[95%] sm:w-full max-w-2xl max-h-[90vh] flex flex-col">
                <h2 className="text-xl font-bold mb-4">{isEditing ? 'Sửa Người dùng' : 'Thêm Người dùng'}</h2>
                <div className="flex-grow overflow-y-auto pr-2 space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Họ và tên</label>
                      <input type="text" value={currentUser.fullName} onChange={e => setCurrentUser({ ...currentUser, fullName: e.target.value })} className={formInputStyle} />
                    </div>
                     <div>
                      <label className="block text-sm font-medium text-gray-700">Chức danh</label>
                      <input type="text" value={currentUser.title} onChange={e => setCurrentUser({ ...currentUser, title: e.target.value })} className={formInputStyle} />
                    </div>
                  </div>
                   <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Tên đăng nhập</label>
                      <input type="text" value={currentUser.username} onChange={e => setCurrentUser({ ...currentUser, username: e.target.value })} className={formInputStyle} />
                    </div>
                     <div>
                      <label className="block text-sm font-medium text-gray-700">Mật khẩu</label>
                      <input type="password" value={currentUser.password} onChange={e => setCurrentUser({ ...currentUser, password: e.target.value })} className={formInputStyle} />
                    </div>
                  </div>
                   <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Số điện thoại</label>
                      <input type="tel" value={currentUser.phone} onChange={e => setCurrentUser({ ...currentUser, phone: e.target.value })} className={formInputStyle} />
                    </div>
                     <div>
                      <label className="block text-sm font-medium text-gray-700">Vai trò</label>
                      <select value={currentUser.role} onChange={e => setCurrentUser({ ...currentUser, role: e.target.value as UserRole })} className={formSelectStyle}>
                        {Object.values(UserRole).map(role => (
                          <option key={role} value={role}>{role}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                  <div>
                    <h3 className="text-md font-semibold text-gray-800 border-t pt-4 mt-4">Phân quyền</h3>
                    <div className="grid grid-cols-2 gap-x-6 gap-y-2 mt-2">
                        {AVAILABLE_PERMISSIONS.map(permission => (
                            <label key={permission.id} className="flex items-center space-x-2 text-sm">
                                <input 
                                    type="checkbox"
                                    className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                                    checked={selectedPermissions.has(permission.id)}
                                    onChange={e => handlePermissionChange(permission.id, e.target.checked)}
                                />
                                <span>{permission.description}</span>
                            </label>
                        ))}
                    </div>
                  </div>
                </div>

                <div className="flex justify-end space-x-4 mt-6 pt-4 border-t">
                    <button onClick={onClose} className="bg-gray-200 text-gray-800 py-2 px-4 rounded-lg font-semibold hover:bg-gray-300">Hủy</button>
                    <button onClick={handleSave} className="bg-primary text-white py-2 px-4 rounded-lg font-semibold hover:bg-primary-dark">Lưu</button>
                </div>
            </div>
        </div>
    );
};

const LoginPage: React.FC<{
  onLogin: (user: User) => void;
  users: User[];
}> = ({ onLogin, users }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const user = users.find(u => u.username === username);

    if (user && user.password === password) {
      if (user.status === 'Hoạt động') {
        onLogin(user);
      } else {
        setError('Tài khoản của bạn đã bị đóng băng.');
      }
    } else {
      setError('Tên đăng nhập hoặc mật khẩu không chính xác.');
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-light-bg p-4">
      <div className="w-full max-w-md p-8 space-y-6 bg-white rounded-lg shadow-md">
        <h1 className="text-3xl font-bold text-center text-dark-text">Đăng nhập</h1>
        {error && <p className="text-red-500 text-center bg-red-100 p-2 rounded-md">{error}</p>}
        <form onSubmit={handleLogin} className="space-y-6">
          <div>
            <label className="text-sm font-bold text-gray-600 block">Tên đăng nhập</label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full p-2 mt-1 border rounded-md focus:border-primary focus:ring focus:ring-primary-dark focus:ring-opacity-50"
              required
            />
          </div>
          <div>
            <label className="text-sm font-bold text-gray-600 block">Mật khẩu</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full p-2 mt-1 border rounded-md focus:border-primary focus:ring focus:ring-primary-dark focus:ring-opacity-50"
              required
            />
          </div>
          <div>
            <button type="submit" className="w-full py-2 px-4 bg-primary text-white rounded-md font-semibold hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-dark">
              Đăng nhập
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};


// --- Main App Component ---

const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<Page>(Page.Dashboard);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [items, setItems] = useState<Item[]>(INITIAL_ITEMS);
  const [slips, setSlips] = useState<InventorySlip[]>(INITIAL_INVENTORY_SLIPS);
  const [requisitions, setRequisitions] = useState<Requisition[]>(INITIAL_REQUISITIONS);
  const [users, setUsers] = useState<User[]>(INITIAL_USERS);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  // Settings states
  const [categories, setCategories] = useState<Category[]>(INITIAL_CATEGORIES);
  const [subsystems, setSubsystems] = useState<Subsystem[]>(INITIAL_SUBSYSTEMS);
  const [costCodes, setCostCodes] = useState<CostCode[]>(INITIAL_COST_CODES);
  const [requisitionTypes, setRequisitionTypes] = useState<RequisitionType[]>(INITIAL_REQUISITION_TYPES);


  const { calculatedInventory, lowStockItems, highStockItems, itemMap } = useMemo(() => {
    const itemMap = new Map<string, Item>(items.map(i => [i.id, i]));
    
    const calculatedInventory: CalculatedInventoryItem[] = items.map(item => {
      let totalReceipts = 0;
      let totalIssues = 0;
  
      slips.forEach(slip => {
        // Only include closed/completed slips for receipts, but all issues to reserve stock
        if (slip.status !== 'Đang mở' || slip.type === SlipType.Issue) {
          slip.items.forEach(slipItem => {
            if (slipItem.itemId === item.id) {
              if (slip.type === SlipType.Receipt) {
                 if (slip.status !== 'Đang mở') {
                    totalReceipts += slipItem.quantity;
                 }
              } else if (slip.type === SlipType.Issue) {
                totalIssues += slipItem.quantity;
              }
            }
          });
        }
      });
  
      const stock = item.initialStock + totalReceipts - totalIssues;
  
      return {
        item,
        stock,
        totalReceipts,
        totalIssues,
      };
    });
  
    const lowStockItems = calculatedInventory.filter(i => i.stock < i.item.warningThresholdLower);
    const highStockItems = calculatedInventory.filter(i => i.stock > i.item.warningThresholdUpper && i.item.warningThresholdUpper > 0);
  
    return { calculatedInventory, lowStockItems, highStockItems, itemMap };
  }, [items, slips]);


  const addLog = (action: string, details: string) => {
    const newLog: LogEntry = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toLocaleString('vi-VN'),
      user: currentUser?.fullName || 'Hệ thống',
      action,
      details,
    };
    setLogs(prevLogs => [newLog, ...prevLogs]);
  };
  
  // FIX: Explicitly type navItems to ensure `requiredPermissions` is `Permission[]` not `string[]`.
  const navItems = useMemo((): {
    page: Page;
    label: string;
    // FIX: Replace JSX.Element with React.ReactElement to resolve "Cannot find namespace 'JSX'" error.
    icon: (props: React.SVGProps<SVGSVGElement>) => React.ReactElement;
    requiredPermissions: Permission[];
  }[] => [
    { page: Page.Dashboard, label: 'Dashboard', icon: HomeIcon, requiredPermissions: ['view_dashboard'] },
    { page: Page.Items, label: 'Vật tư', icon: BoxIcon, requiredPermissions: ['manage_items'] },
    { page: Page.Receipts, label: 'Phiếu Nhập', icon: ArrowDownCircleIcon, requiredPermissions: ['manage_receipts'] },
    { page: Page.Issues, label: 'Phiếu Xuất', icon: ArrowUpCircleIcon, requiredPermissions: ['manage_issues'] },
    { page: Page.Requisitions, label: 'Tờ trình', icon: FileTextIcon, requiredPermissions: ['manage_requisitions', 'approve_requisitions'] },
    { page: Page.Users, label: 'Người dùng', icon: UsersIcon, requiredPermissions: ['manage_users'] },
    { page: Page.Settings, label: 'Cài đặt', icon: SettingsIcon, requiredPermissions: ['manage_settings'] },
    { page: Page.Log, label: 'Nhật ký', icon: HistoryIcon, requiredPermissions: ['view_logs'] },
  ], []);
  
  const handleLogin = (user: User) => {
    setCurrentUser(user);
    addLog('Đăng nhập', `Người dùng "${user.fullName}" đã đăng nhập.`);
    // Set initial page based on permissions
    const firstAllowedPage = navItems.find(item => 
        item.requiredPermissions.some(p => user.permissions.includes(p))
    );
    setCurrentPage(firstAllowedPage ? firstAllowedPage.page : Page.Dashboard);
  };

  const handleLogout = () => {
    addLog('Đăng xuất', `Người dùng "${currentUser?.fullName}" đã đăng xuất.`);
    setCurrentUser(null);
  };

  const visibleNavItems = useMemo(() => {
    if (!currentUser) return [];
    return navItems.filter(item => 
      item.requiredPermissions.some(p => currentUser.permissions.includes(p))
    );
  }, [currentUser, navItems]);


  if (!currentUser) {
    return <LoginPage onLogin={handleLogin} users={users} />;
  }

  const renderContent = () => {
    switch (currentPage) {
      case Page.Dashboard: return <Dashboard lowStockItems={lowStockItems} highStockItems={highStockItems} currentUser={currentUser} />;
      case Page.Items: return <ItemsPage items={items} setItems={setItems} inventory={calculatedInventory} allSlips={slips} categories={categories} addLog={addLog} currentUser={currentUser} />;
      case Page.Receipts: return <ReceiptsPage allSlips={slips} setAllSlips={setSlips} requisitions={requisitions} setRequisitions={setRequisitions} items={items} itemMap={itemMap} addLog={addLog} currentUser={currentUser} />;
      case Page.Issues: return <IssuesPage allSlips={slips} setAllSlips={setSlips} items={items} itemMap={itemMap} subsystems={subsystems} costCodes={costCodes} addLog={addLog} currentUser={currentUser} />;
      case Page.Requisitions: return <RequisitionsPage requisitions={requisitions} setRequisitions={setRequisitions} items={items} itemMap={itemMap} requisitionTypes={requisitionTypes} subsystems={subsystems} costCodes={costCodes} addLog={addLog} currentUser={currentUser} />;
      case Page.Users: return <UsersPage users={users} setUsers={setUsers} addLog={addLog} currentUser={currentUser} />;
      case Page.Settings: return <SettingsPage 
          categories={categories} setCategories={setCategories}
          subsystems={subsystems} setSubsystems={setSubsystems}
          costCodes={costCodes} setCostCodes={setCostCodes}
          requisitionTypes={requisitionTypes} setRequisitionTypes={setRequisitionTypes}
          addLog={addLog}
          currentUser={currentUser}
        />;
      case Page.Log: return <LogPage logs={logs} />;
      default: return <Dashboard lowStockItems={lowStockItems} highStockItems={highStockItems} currentUser={currentUser}/>;
    }
  };

  return (
    <div className="flex h-screen bg-gray-100 font-sans overflow-hidden">
      <aside className={`fixed inset-y-0 left-0 z-40 w-64 bg-gray-800 text-white flex flex-col flex-shrink-0 transform transition-transform duration-300 ease-in-out md:static md:translate-x-0 ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="h-16 flex items-center justify-center text-2xl font-bold border-b border-gray-700">
          <span>Kho Hàng</span>
        </div>
        <nav className="flex-grow">
          <ul className="py-4">
            {visibleNavItems.map(item => (
              <li key={item.page} className="px-4">
                <a
                  href="#"
                  onClick={(e) => { e.preventDefault(); setCurrentPage(item.page); setIsSidebarOpen(false); }}
                  className={`flex items-center p-3 my-1 text-lg rounded-md transition-colors ${
                    currentPage === item.page
                      ? 'bg-gray-900 text-white font-semibold'
                      : 'text-gray-300 hover:bg-gray-700 hover:text-white'
                  }`}
                >
                  <item.icon className="mr-4" />
                  <span>{item.label}</span>
                </a>
              </li>
            ))}
          </ul>
        </nav>
      </aside>
      {isSidebarOpen && <div className="fixed inset-0 bg-black bg-opacity-50 z-30 md:hidden" onClick={() => setIsSidebarOpen(false)}></div>}
      <div className="flex-1 flex flex-col overflow-hidden">
          <header className="bg-white shadow-md h-16 flex items-center justify-between md:justify-end px-4 sm:px-8 flex-shrink-0">
               <button 
                className="text-gray-500 hover:text-gray-800 focus:outline-none md:hidden" 
                onClick={() => setIsSidebarOpen(true)}
                aria-label="Open sidebar"
              >
                <MenuIcon className="h-6 w-6" />
              </button>
              <div className="flex items-center space-x-4">
                  <span className="font-semibold text-gray-700 hidden sm:inline">Chào, {currentUser.fullName}</span>
                  <button onClick={handleLogout} className="text-gray-500 hover:text-red-600 flex items-center space-x-2" title="Đăng xuất">
                      <LogOutIcon />
                      <span className="hidden sm:inline">Đăng xuất</span>
                  </button>
              </div>
          </header>
          <main className="flex-1 p-4 sm:p-8 overflow-y-auto">
            {renderContent()}
          </main>
      </div>
    </div>
  );
};

export default App;