
import { GoogleGenAI } from "@google/genai";
import type { InventoryItem } from '../types';

// FIX: Per coding guidelines, initialize GoogleGenAI directly assuming `process.env.API_KEY` is available.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const suggestRestock = async (lowStockItems: InventoryItem[]): Promise<string> => {
  const prompt = `
    Bạn là một chuyên gia quản lý kho hàng. Dựa vào danh sách các vật tư sắp hết hàng sau đây, hãy đưa ra một đề xuất nhập hàng chuyên nghiệp.
    Mục tiêu là đề xuất số lượng cần nhập để đạt mức tồn kho an toàn là 20 đơn vị cho mỗi loại.
    
    Dữ liệu vật tư sắp hết:
    ${JSON.stringify(lowStockItems.map(i => ({ name: i.item.name, unit: i.item.unit, currentStock: i.stock })), null, 2)}
    
    Yêu cầu đầu ra:
    - Bắt đầu với một tiêu đề "Đề xuất nhập hàng".
    - Viết một đoạn giới thiệu ngắn gọn.
    - Liệt kê từng vật tư cần nhập dưới dạng gạch đầu dòng, bao gồm tên vật tư, số lượng đề xuất cần nhập và lý do (để đạt mức tồn kho an toàn 20).
    - Kết thúc bằng một câu kêu gọi hành động.
    - Sử dụng ngôn ngữ tiếng Việt.
  `;

  try {
    // FIX: Call the Gemini API to generate content.
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    // FIX: Extract text from the response using the `.text` property.
    return response.text;
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    return "Đã xảy ra lỗi khi kết nối với AI. Vui lòng thử lại sau.";
  }
};
